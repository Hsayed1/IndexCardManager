package application.personalIndexCardManager;


public class IndexCard {
	private String term;
	private String definition;
	private String parentCourse;
	
	public IndexCard(String t, String d, String pC) {
		this.term = t;
		this.definition = d;
		this.parentCourse = pC;
	}
	
	public String getTerm() {
		return this.term;
	}
	
	public String getDefinition() {
		return this.definition;
	}
	
	public String getParentCourse() {
		return this.parentCourse;
	}
	
}
