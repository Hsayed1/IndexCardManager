package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.courseData.*;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.Course;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class CourseRenameController implements Initializable {
	private final static String DATABASE = "usersTest.db";

	@FXML private Button submitNameBtn;

	@FXML private TextField nameSubmission;

	@FXML private Label wrongNameError;
	
	@FXML public void checkNameOp() throws IOException {
		String name = nameSubmission.getText();	

		// Check input with database 
		CourseDataAccessible con1 = new SQLiteCourseAccessor();
		CourseDataUpdatable con2 = new SQLiteCourseUpdater();
		
		// Connects to database to get index card data
		IndexCardDataInt con3 = new SQLiteIndexCard();
		
		//first check if there exists the input in the database
		if (!(con1.checkName(DATABASE, name)))
		{
			// Update course and index card's association to the database
			con2.updateCourseName(DATABASE, new Course(name));
			con3.updateAssociatedCourse(DATABASE, new Course(name));
			
			// Changes "active" status of old course to new name
			con2.storeCurrentCourse(DATABASE, new Course(name));
			
			// set error to be invisible
			wrongNameError.setVisible(false);
			
			//return to courses page
			Stage stage = (Stage)submitNameBtn.getScene().getWindow();
			stage.close();
			Main m = new Main();
			m.changeScene("fxml/IndexCard.fxml");
			
		}
		else {
			System.out.println("Conflicted names detected");
			wrongNameError.setVisible(true);
			wrongNameError.setText("*That name exists in your courses*");
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
	}



}
