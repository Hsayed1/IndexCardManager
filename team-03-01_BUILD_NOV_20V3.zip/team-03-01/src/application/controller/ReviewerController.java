package application.controller;

import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class ReviewerController implements Initializable 
{
	private final static String DATABASE = "usersTest.db";
	
	@FXML private Label Term;
	@FXML private Label Definition;
	@FXML private Label errorMessage;
	@FXML private CheckBox theCheckBox;
	
	private IndexCard currentCard;
	private List<IndexCard> allCards;
	private int numOfCards;
	private int currentCardNumber;

	@FXML public void showDefOp() {
		if(currentCardNumber <= numOfCards)
		{
			Definition.setText("Definition: " + currentCard.getDefinition());
			Definition.setVisible(true);
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}		
	}

	@FXML public void nextCardOp() {
		if(ReviewCardsController.getSelection().equals("Review learned"))
			nextLearnedCard();
		else if(ReviewCardsController.getSelection().equals("Review unlearned")) 
			nextUnlearnedCard();
		else
			nextCard();
		}

	@FXML public void checkBoxOp() {
		if(theCheckBox.isSelected() == true)
		{
			this.currentCard.setIsLearned(1);
			theCheckBox.setText("Uncheck to unlearn");
			theCheckBox.setSelected(true);
			theCheckBox.setVisible(true);
		}
		else
		{
			this.currentCard.setIsLearned(0);
			theCheckBox.setText("Check to learn");
			theCheckBox.setSelected(false);
			theCheckBox.setVisible(true);	
		}
	}
	
	@FXML public void backOp(ActionEvent event) {
		URL url = getClass().getClassLoader().getResource("fxml/ReviewCards.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		//String selection = ReviewCardsController.getSelection();
		errorMessage.setVisible(false);
		IndexCardDataInt con = new SQLiteIndexCard();
	
		// Gets all index cards associated with the current course & other settings
		this.allCards = con.getIndexCards(DATABASE);
		numOfCards = allCards.size();
		currentCardNumber = 0;
		
		// Checks selection to see which index cards are needed to be reviewed
		if(ReviewCardsController.getSelection().equals("Review learned"))
			reviewLearned();
		else if(ReviewCardsController.getSelection().equals("Review unlearned"))
			reviewUnlearned();
		else
			reviewAll();
		
	}
	
	private void reviewAll()
	{
		currentCard = allCards.get(currentCardNumber);
		
		if(currentCard != null)
		{
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			if(currentCard.getIsLearned() == true)
			{
				theCheckBox.setText("Uncheck to unlearn");
				theCheckBox.setSelected(true);
				theCheckBox.setVisible(true);
			}
			else
			{
				theCheckBox.setText("Check to learn");
				theCheckBox.setSelected(false);
				theCheckBox.setVisible(true);
			}
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
	}
	
	private void reviewLearned()
	{
		currentCard = allCards.get(currentCardNumber);
		while(currentCard.getIsLearned() != true)
		{
			currentCardNumber++;
			if(currentCardNumber > allCards.size())
			{
				errorMessage.setText("*All cards have been reviewed*");
				errorMessage.setVisible(true);
				break;
			}
			currentCard = allCards.get(currentCardNumber);
		}
		if(currentCard != null)
		{
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			theCheckBox.setText("Uncheck to unlearn");
			theCheckBox.setSelected(true);
			theCheckBox.setVisible(true);
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
	}
	
	private void reviewUnlearned()
	{
		currentCard = allCards.get(currentCardNumber);
		while(currentCard.getIsLearned() == true)
		{
			currentCardNumber++;
			if(currentCardNumber > allCards.size())
			{
				errorMessage.setText("*All cards have been reviewed*");
				errorMessage.setVisible(true);
				break;
			}
			currentCard = allCards.get(currentCardNumber);
		}
		if(currentCard != null)
		{
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			theCheckBox.setText("Check to learn");
			theCheckBox.setSelected(false);
			theCheckBox.setVisible(true);
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
	}
	
	private void nextLearnedCard()
	{
		currentCardNumber++;
		if (currentCardNumber < numOfCards )
		{
			currentCard = allCards.get(currentCardNumber);
			while(currentCard.getIsLearned() != true)
			{
				currentCardNumber++;
				if(currentCardNumber > numOfCards )
				{
					errorMessage.setText("*All cards have been reviewed*");
					errorMessage.setVisible(true);
					break;
				}
				currentCard = allCards.get(currentCardNumber);
			}
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);
			theCheckBox.setText("Uncheck to unlearn");
			theCheckBox.setSelected(true);
			theCheckBox.setVisible(true);
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}
	}
	
	private void nextUnlearnedCard()
	{
		currentCardNumber++;
		if (currentCardNumber < numOfCards)
		{
			currentCard = allCards.get(currentCardNumber);
			while(currentCard.getIsLearned() == true)
			{
				currentCardNumber++;
				if(currentCardNumber > numOfCards)
				{
					errorMessage.setText("*All cards have been reviewed*");
					errorMessage.setVisible(true);
					break;
				}
				currentCard = allCards.get(currentCardNumber);
			}
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);
			theCheckBox.setText("Check to learn");
			theCheckBox.setSelected(false);
			theCheckBox.setVisible(true);
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}
		
	}
	
	private void nextCard()
	{
		currentCardNumber++;
		if (currentCardNumber < numOfCards)
		{
			currentCard = allCards.get(currentCardNumber);
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);	
			if(currentCard.getIsLearned() == true)
			{
				theCheckBox.setText("Uncheck to unlearn");
				theCheckBox.setSelected(true);
				theCheckBox.setVisible(true);
			}
			else
			{
				theCheckBox.setText("Check to learn");
				theCheckBox.setSelected(false);
				theCheckBox.setVisible(true);
			}
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}
	}

}
