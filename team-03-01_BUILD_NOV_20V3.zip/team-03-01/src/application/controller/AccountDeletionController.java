package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.courseData.CourseDataUpdatable;
import application.databaseConnector.courseData.SQLiteCourseUpdater;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.databaseConnector.userData.SQLiteUserAccessor;
import application.databaseConnector.userData.SQLiteUserUpdater;
import application.databaseConnector.userData.UserDataUpdatable;
import javafx.event.ActionEvent;

public class AccountDeletionController implements Initializable {
	
	private final static String DATABASE = "usersTest.db";

	@FXML private Button deleteBtn;
	@FXML private CheckBox checkDelete;
	@FXML private Button accManBackBtn;
	@FXML private Label errorLbl;
	
	/*
	 * Deletes ALL data regarding the "logged in"
	 * account
	 * 
	 */
	@FXML public void deleteAccountOp(ActionEvent event) {
		// Establishes connection to database
		UserDataUpdatable con1 = new SQLiteUserUpdater();
		CourseDataUpdatable con2 = new SQLiteCourseUpdater();
		IndexCardDataInt con3 = new SQLiteIndexCard();
		SQLiteConnectorInt con4 = new SQLiteUserAccessor();
		
		// Checks to see if the check mark is checked
		if (checkDelete.isSelected()) {
					
			// deletes ALL data associated with the current account
			con3.deleteAllIndexCards(DATABASE);
			con2.deleteAllCourses(DATABASE);
			con1.deleteUser(DATABASE);
			
			// Remove "active" status of now deleted email
			con4.removeStoredEmail(DATABASE);
					
			// Hides error label
			errorLbl.setVisible(false);
					
			// Change windows
			Stage stage = (Stage)deleteBtn.getScene().getWindow();
			stage.close();
			Main m = new Main();
			m.changeScene("fxml/Home.fxml");
			
		} else {
			// Displays error in deleting the course
			errorLbl.setVisible(true);
			errorLbl.setText("***You must check the box to delete the account***");
			System.out.println("Cannot delete without the checkmark being checked");
		}
	}
	
	/*
	 * Goes back to Account Management
	 * 
	 */
	@FXML public void goToAccountManagement(ActionEvent event) {
		Stage stage = (Stage)accManBackBtn.getScene().getWindow();
		stage.close();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// set visibility to false
		errorLbl.setVisible(false);
	}

}
