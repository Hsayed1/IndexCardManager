package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.userData.SQLiteUserAccessor;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class AccountManagementController implements Initializable {

	private final static String DATABASE = "usersTest.db";
	
	@FXML private BorderPane loginScene;
	@FXML private Button courseBtn;
	@FXML private Label activeUser;
	@FXML private Button deleteAccBtn;
	@FXML private Button modifyAccBtn;
	
	/*
	 * Go to Courses page
	 * 
	 */
	@FXML public void goToCourses(ActionEvent event) {
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/Courses.fxml");
												
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
												
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * Deletes the account using prompts to affirm
	 * the decision
	 * 
	 */
	@FXML public void deleteAccount(ActionEvent event) {
		try {
			// Loads a delete prompt
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("fxml/AccountDeletion.fxml"));
			
			// Settings for the deletion prompt
			primaryStage.setTitle("Delete Account");
			primaryStage.setScene(new Scene(root, 500, 300));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Modifies the data regarding the active user
	 * 
	 */
	@FXML public void modifyAccount(ActionEvent event) {
		try {
			// Loads a modify account prompt
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("fxml/AccountModification.fxml"));
			
			// Settings for the modification prompt
			primaryStage.setTitle("Modify Account");
			primaryStage.setScene(new Scene(root, 500, 300));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Changes the color of the Back to 
	 * Courses button
	 * 
	 */
	@FXML public void changeCourseBtnColor() {
		courseBtn.setStyle("-fx-background-color: #add538");
		courseBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Reverts the color of the Back to Courses
	 * button to its original color
	 * 
	 */
	@FXML public void revertCourseBtnColor() {
		courseBtn.setStyle("-fx-background-color: #522AC7");
		courseBtn.setTextFill(Color.WHITE);
	}

	/*
	 * Changes color of the Delete Account button
	 * 
	 */
	@FXML public void changeDeleteAccColor() {
		deleteAccBtn.setStyle("-fx-background-color: #add538");
		deleteAccBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Reverts the color of the Delete Account button
	 * back to its original color
	 * 
	 */
	@FXML public void revertDeleteAccColor() {
		deleteAccBtn.setStyle("-fx-background-color: #522AC7");
		deleteAccBtn.setTextFill(Color.WHITE);
	}

	/*
	 * Changes color of the Modify Account button
	 * 
	 */
	@FXML public void changeModAccColor() {
		modifyAccBtn.setStyle("-fx-background-color: #add538");
		modifyAccBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Reverts the color of the Modify Account button
	 * back to its original color
	 * 
	 */
	@FXML public void revertModAccColor() {
		modifyAccBtn.setStyle("-fx-background-color: #522AC7");
		modifyAccBtn.setTextFill(Color.WHITE);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Sets the active user to the current account that is currently
		// logged in
		SQLiteConnectorInt con = new SQLiteUserAccessor();
		activeUser.setText("Active User: " + con.getStoredEmail(DATABASE));
		
	}

}
