package application.databaseConnector.userData;

import java.util.List;

import application.personalIndexCardManager.User;

public interface UserDataAccessible {

	List<User> getAllUsers(String database);

	boolean findEmail(String database, String email);

	boolean findPass(String database, String email, String password);

	String getSecQuest(String database);
	
	boolean findAnswer(String database, String securityAns);
	
}