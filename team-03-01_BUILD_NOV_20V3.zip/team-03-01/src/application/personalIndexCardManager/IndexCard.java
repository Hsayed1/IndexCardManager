package application.personalIndexCardManager;


public class IndexCard {
	private String term;
	private String definition;
	private String parentCourse;
	private boolean isLearned;
	
	public IndexCard(String t, String d, String pC) {
		this.term = t;
		this.definition = d;
		this.parentCourse = pC;
		isLearned = false;
	}
	
	public IndexCard(String term, String def, String parentCourse, boolean isLearned) {
		this.term = term;
		this.definition = def;
		this.parentCourse = parentCourse;
		this.isLearned = isLearned;
	}
	
	public String getTerm() {
		return this.term;
	}
	
	public String getDefinition() {
		return this.definition;
	}
	
	public String getParentCourse() {
		return this.parentCourse;
	}
	
	public boolean getIsLearned() {
		return this.isLearned;
	}
	
	public void setIsLearned(int bit) {
		if (bit == 0) {
			this.isLearned = false;
			return;
		}
		this.isLearned = true;
	}
	
	/*
	 * Returns the integer equivalent of
	 * false or true
	 * 
	 */
	public int getIsLearnedBit() {
		if (isLearned)
			return 1;
		return 0;
	}
	
	@Override
	public String toString() {
		String s = term + "," + definition + "," + isLearned;
		return s;
	}
}
