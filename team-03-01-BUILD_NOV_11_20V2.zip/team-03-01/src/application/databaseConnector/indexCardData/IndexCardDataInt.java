package application.databaseConnector.indexCardData;

import java.util.List;

import application.personalIndexCardManager.IndexCard;

public interface IndexCardDataInt {

	void addIndexCard(String database, IndexCard ic);
	
	void deleteIndexCard(String database, IndexCard ic);
	
	void updateIndexCard(String database, IndexCard newIC);
	
	List<IndexCard> getIndexCards(String database);
	
	void deleteAllIndexCards(String database);

	void updateAssociatedEmail(String database, String newEmail);
}
