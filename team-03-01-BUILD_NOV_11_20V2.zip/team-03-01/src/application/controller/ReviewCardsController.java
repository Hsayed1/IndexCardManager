package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;

public class ReviewCardsController implements Initializable{

	private static String selection;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

	@FXML public void reviewAllOp(ActionEvent event) {
		selection = "Review all";
		URL url = getClass().getClassLoader().getResource("fxml/Reviewer.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	@FXML public void reviewLearnedOp(ActionEvent event) {
		selection = "Review learned";
		URL url = getClass().getClassLoader().getResource("fxml/Reviewer.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	@FXML public void reviewUnlearnedOp(ActionEvent event) {
		selection = "Review unlearned";
		URL url = getClass().getClassLoader().getResource("fxml/Reviewer.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	static String getSelection()
	{
		return selection;
	}

	@FXML public void backOp(ActionEvent event) {
		URL url = getClass().getClassLoader().getResource("fxml/IndexCard.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}

}
