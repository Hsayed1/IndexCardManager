package application.personalIndexCardManager;

import java.util.List;

public interface CourseDataInt {

	void storeCurrentCourse(String database, Course currentCourse);

	void addCourse(String database, Course course);

	List<Course> getCourses(String database);

	void updateCourseName(String database, Course newCourse);

	void deleteCourse(String database);
	
	boolean checkName(String database, String name);
}