package application.personalIndexCardManager;

import java.util.List;

public interface UserDataInt {

	void addUser(String database, User user);

	List<User> getAllUsers(String database);

	boolean findEmail(String database, String email);

	boolean findPass(String database, String email, String password);

	String getSecQuest(String database);
	
	void storeEmailInput(String database, String emailInput);
	
	boolean findAnswer(String database, String securityAns);

	void resetPassword(String database, String newPassword);
}