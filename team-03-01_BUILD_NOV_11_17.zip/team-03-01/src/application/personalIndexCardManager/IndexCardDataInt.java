package application.personalIndexCardManager;

import java.util.List;

public interface IndexCardDataInt {

	void addIndexCard(String database, IndexCard ic);
	
	void deleteIndexCard(String database, IndexCard ic);
	
	void updateIndexCard(String database, IndexCard newIC);
	
	List<IndexCard> getIndexCards(String database);
	
}
