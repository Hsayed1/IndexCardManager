package application.personalIndexCardManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * This class handles data regarding index cards
 * 
 */
public class SQLiteIndexCard implements SQLiteConnectorInt, IndexCardDataInt {

	/*
	 * Adds the data of the index card into the database
	 * 
	 * @param database the name of the database
	 * @param ic the index card to be added to the database
	 */
	@Override
	public void addIndexCard(String database, IndexCard ic) {
		// PreparedStatement String to add/insert a new index card into the database
		// using relevant information that indicates its content and identification
		String sql = "INSERT INTO IndexCards (email, courseName, term, definition, isLearned) VALUES(?,?,?,?,?)";

    	// Establishes a connection to the database
    	// Prepares a statement
    	try (Connection conn = this.connect(database);
    			PreparedStatement statement = conn.prepareStatement(sql)) {
    		
    		// Extracts data from IndexCard object and put into database
    		// Also gets the "active" email to provide identification
    		statement.setString(1, this.getStoredEmail(database));
    		statement.setString(2, ic.getParentCourse());
    		statement.setString(3, ic.getTerm());
    		statement.setString(4, ic.getDefinition());
    		statement.setInt(5, 0);
           
    		// Updates database
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		conn.close();
    		statement.close();
    		System.out.println("Added new index card");
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}

	/*
	 * Gets a list of index cards under the "active"
	 * or "logged in" account
	 * 
	 * @param database the name of the database
	 * @return the list of index cards under the account
	 */
	@Override
	public List<IndexCard> getIndexCards(String database) {
		// Creates a new list of index cards
    	List<IndexCard> indexCards = new ArrayList<IndexCard>();
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	// It gets all index cards belonging to the email from the database
    	String sql = "SELECT email, courseName, term, definition, isLearned FROM IndexCards WHERE email = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the "active" or "logged in" email and uses it
    		// to get all index cards that belong to this email
    		String email = this.getStoredEmail(database);
    		statement.setString(1, email);
    		
    		// Pulls data from the database
    		ResultSet rs  = statement.executeQuery();
    		
    		// Stores pulled data into the list
    		while(rs.next()) {
    			indexCards.add(new IndexCard(rs.getString("term"), 
    					rs.getString("definition"), 
    					rs.getString("courseName")));
    		}
    		
    		// Closes connection, result set, and statement
    		// to prevent leaks
    		con.close();
    		rs.close();
    		statement.close();
    		
    		// Returns a list of index cards that belong
    		// to the current "active" or "logged in" email
    		return indexCards;
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return null;
	}

	/*
	 * Deletes an index card from the database
	 * 
	 * @param database the name of the database 
	 * 
	 */
	@Override
	public void deleteIndexCard(String database, IndexCard ic) {
		// PreparedStatement String to remove a specific index card from the database
		String sql = "DELETE FROM IndexCards WHERE term = ? and definition = ?";
		
		try {
			// Connects to database and prepares the sql String
			// into a statement to remove the 
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Gets the
			pstm.setString(1, ic.getTerm());
			pstm.setString(2, ic.getDefinition());
			
			// Updates the database
			pstm.executeUpdate();
			
			// Closes the connection and PreparedStatement
			// to prevent background leakage
			con.close();
			pstm.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	/*
	 * Updates the contents of the index card
	 * [****UNDER CONSTRUCTION****]
	 * 
	 * @param database the name of the database
	 * @param oldIC the old index card with old term and definition
	 * @param newIC the new index card with updated term and definition
	 */
	@Override
	public void updateIndexCard(String database, IndexCard newIC) {
		// PreparedStatement String to update the current index card
		String sql = "UPDATE IndexCards SET term = ?, definition = ?, isLearned = ? "
				+ "WHERE email = ? and courseName = ?";
		try {
			// Connects to database and prepares statement to execute
			// what sql String is commanding 
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Sets the current index card to the updated term
			// and definition 
			pstm.setString(1, newIC.getTerm());
			pstm.setString(2, newIC.getDefinition());
			pstm.setInt(3, newIC.getIsLearnedBit());				// PLACEHOLDER for review function
			pstm.setString(4, this.getStoredEmail(database));
			pstm.setString(5, this.getCurrentCourse(database));
			
			// Updates the database
			pstm.executeUpdate();
			
			// Closes the connection and PreparedStatement
			// to prevent background leakage
			con.close();
			pstm.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
}
