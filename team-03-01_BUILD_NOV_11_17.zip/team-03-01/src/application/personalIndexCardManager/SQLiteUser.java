package application.personalIndexCardManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/*
 * This class handles data regarding users
 * 
 */
public class SQLiteUser implements SQLiteConnectorInt, UserDataInt {

    /*
     * Inserts a new user into the database
     * 
     * @param database the name of the database
     * @param user the user to be added to the database
     */
	@Override
    public void addUser(String database, User user) {
    	String sql = "INSERT INTO Users (email, password, securityQuest, securityAns, userID) VALUES(?,?,?,?,?)";

    	// Establishes a connection to the database
    	// Prepares a statement
    	try (Connection conn = this.connect(database);
    			PreparedStatement statement = conn.prepareStatement(sql)) {
    		
    		// Extracts data from user object and put into database
    		statement.setString(1, user.getEmail());
    		statement.setString(2, user.getPass());
    		statement.setString(3, user.getSecurityQuest());
    		statement.setString(4, user.getSecurityAns());
    		
    		// Sets up user ID
    		String userID = user.getEmail().replace('@', '_');
    		userID.replace('.', '_');
    		//System.out.println(userID);
    		statement.setString(5, userID);
           
    		// Updates database
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		conn.close();
    		statement.close();
    		System.out.println("Added new user");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /*
     * Check database for the specified user
     * 
     * @param database the name of the database
     */
	@Override
    public List<User> getAllUsers(String database) {
    	
    	// List of users
    	List<User> users = new ArrayList<User>();
    	
    	// PreparedStatement where it pulls data from the specified table in the specified database
    	String sql = "SELECT email, password, securityQuest, securityAns FROM Users";
    	try {
    		Connection conn = this.connect(database);
    		Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
                
    		// loop through the result set
    		while (rs.next()) {
    			users.add(new User(rs.getString("email"),rs.getString("password"), rs.getString("securityQuest"), rs.getString("securityAns")));
    			System.out.println(rs.getString("email") +  "\t" + 
            		   rs.getString("password") + "\t" +
                       rs.getString("securityQuest") + "\t" +
                       rs.getString("securityAns"));
            }
            // Closes connection, result set, and statement
       		conn.close();
       		rs.close();
       		stmt.close();
       		return users;
               
        } catch (SQLException e) {
        	e.getStackTrace();
        }
   		return null;
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     * @param email the email input
     */
	@Override
    public boolean findEmail(String database, String email) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	// with the desired username from the database
    	String sql = "SELECT email FROM Users WHERE email = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the user with the desired email
    		statement.setString(1, email);
    		
    		// Check if user is found in the database
    		ResultSet rs  = statement.executeQuery();
    		if (rs.next()) {
                System.out.println(rs.getString("email"));
                
                // Closes connection, result set, and statement
           		con.close();
           		rs.close();
           		statement.close();
           		return true;
            }
    		// Closes connection, result set, and statement
       		con.close();
       		rs.close();
       		statement.close();
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return false;
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     * @param the email input
     * @param password the password input
     */
	@Override
    public boolean findPass(String database, String email, String password) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	// with the desired password in the specified database
    	String sql = "SELECT email, password FROM Users WHERE email = ? and password = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the user with the desired password
    		statement.setString(1, email);
    		statement.setString(2, password);
    		
    		// Check if user is found in the database
    		ResultSet rs  = statement.executeQuery();
    		if (rs.next()) {
                System.out.println(rs.getString("email") + "\t" +
                		rs.getString("password"));
                // Closes connection, result set, and statement
        		con.close();
        		rs.close();
        		statement.close();
                return true;
            }
    		// Closes connection, result set, and statement
    		con.close();
    		rs.close();
    		statement.close();
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return false;
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     */
	@Override
    public String getSecQuest(String database) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	String sql = "SELECT email, securityQuest FROM Users WHERE email = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the user's security question
    		String email = this.getStoredEmail(database);
    		System.out.println("Got " + email);
    		statement.setString(1, email);
    		
    		// Pulls data from the database
    		ResultSet rs  = statement.executeQuery();
    		
    		// Checks to see if it can get the specified data
    		if (rs.next()) {
                System.out.println(rs.getString("email") + "\t" +
                		rs.getString("securityQuest"));
                
                // Gets the security question associated with the email
                String secQuest = rs.getString("SecurityQuest");
                
                // Closes connection, result set, and statement
        		con.close();
        		rs.close();
        		statement.close();
                return secQuest;
            }
    		// Closes connection, result set, and statement
    		con.close();
    		rs.close();
    		statement.close();
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return null;
    }
    
    /*
     * Stores the email input 
     * 
     * @param database the name of the database
     */
	@Override
	public void storeEmailInput(String database, String emailInput) {
    	
    	// Removes any stored or "active" email
    	this.removeStoredEmail(database);
    	
    	// PreparedStatement String to insert email input into database
    	String sql = "INSERT INTO GETEMAIL (EMAIL) VALUES(?)";

    	// Establishes a connection to the database
    	// Prepares a statement
    	try (Connection conn = this.connect(database);
    			PreparedStatement statement = conn.prepareStatement(sql)) {
    		
    		// Extracts data from user object and put into database
    		statement.setString(1, emailInput);
    		System.out.println("Stored " + emailInput);
           
    		// Updates database
    		statement.executeUpdate();
    		conn.close();
        	statement.close();
    		System.out.println("Updated stored email in the database table");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     * @param securityAns the security answer input
     */
    @Override
    public boolean findAnswer(String database, String securityAns) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	String sql = "SELECT email, securityAns FROM Users WHERE email = ? and securityAns = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the "active" or "logged in" email
    		String email = this.getStoredEmail(database);
    		System.out.println(email);
    		statement.setString(1, email);
    		statement.setString(2, securityAns);
    		
    		// Check if that security answer is found in the database
    		// under the specified email
    		ResultSet rs  = statement.executeQuery();
    		if (rs.next()) {
                System.out.println(rs.getString("email") + "\t" +
                		rs.getString("securityAns"));
                
                // Checks to see if there is no other user
                // with the same data, though this should be
                // impossible
                if (rs.next() == false) {
                	con.close();
                	rs.close();
                	statement.close();
                	return true;
                }
            }
    		return false;
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	} 
    	return false;
    }
    
    /*
     * Resets the password of the account in the specified table
     * in the specified database
     * 
     * @param database the name of the database
     * @param newPassword the new password
     */
    @Override
	public void resetPassword(String database, String newPassword) {
		
		// PreparedStatement String to update the password to its new password
		// corresponding to the stored email
		String sql = "UPDATE Users SET password = ? "
                + "WHERE email = ?";

        try (Connection conn = this.connect(database);
                PreparedStatement statement = conn.prepareStatement(sql)) {

            // set the password to the new password
        	String email = this.getStoredEmail(database);
            statement.setString(1, newPassword);
            statement.setString(2, email);
           
            // Updates the password & removes stored email
            statement.executeUpdate();
            this.removeStoredEmail(database);
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

}
