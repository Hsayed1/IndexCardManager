package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.courseData.SQLiteCourseAccessor;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.layout.FlowPane;

public class IndexCardsController implements Initializable {
	
	private final static String DATABASE = "usersTest.db";

	@FXML Button toCoursesBtn;
	@FXML Button deleteBtn;
	@FXML Button renameBtn;
	@FXML Button createCardButton;
	@FXML FlowPane indexCardsPanel;
	@FXML Label currentCourse;


	@FXML public void goToCourses(ActionEvent event) {
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/Courses.fxml");
								
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * Change logout button color when mouse hovers
	 * over the button
	 * 
	 */
	@FXML public void changeToCoursesBtnColor() {
		toCoursesBtn.setStyle("-fx-background-color: #06014a");
		toCoursesBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts logout button color when mouse exits
	 * the button
	 * 
	 */
	@FXML public void revertToCoursesBtnColor() {
		toCoursesBtn.setStyle("-fx-background-color: #F9FEB5");
		toCoursesBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Rename the selected course
	 * 
	 */
	@FXML public void renameCourse() {
		try {
			// Loads a rename prompt
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("fxml/CourseRename.fxml"));
			
			
			// Settings for the rename prompt
			primaryStage.setTitle("Rename the Course");
			primaryStage.setScene(new Scene(root, 500, 300));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Deletes the selected course
	 * 
	 */
	@FXML public void deleteCourse(ActionEvent event) {
		try {
			// Loads a delete prompt
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("fxml/CourseDeletion.fxml"));
			
			
			// Settings for the deletion prompt
			primaryStage.setTitle("Delete the Course");
			primaryStage.setScene(new Scene(root, 500, 300));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Change button color when mouse enters
	 * the button
	 * 
	 */
	@FXML public void changeICCreationColor() {
		createCardButton.setStyle("-fx-background-color: #e5938a");
		createCardButton.setTextFill(Color.BLACK);
	}

	/*
	 * Reverts button color back to original
	 * color
	 * 
	 */
	@FXML public void revertICCreationColor() {
		createCardButton.setStyle("-fx-background-color: #1a6c75");
		createCardButton.setTextFill(Color.WHITE);
	}
	
	/*
	 * Create a new index card
	 */
	@FXML public void createIndexCard(ActionEvent event) {
		//Open new window where the user can enter the card info
		try {
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("fxml/CreateIndexCard.fxml"));
			
			// Settings for the deletion prompt
			primaryStage.setTitle("Create Index Card");
			primaryStage.setScene(new Scene(root, 600, 402));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
			
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		SQLiteConnectorInt con = new SQLiteCourseAccessor();
		currentCourse.setText("Your Index Cards - " + con.getCurrentCourse(DATABASE));		
	}


}
