package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.event.ActionEvent;

public class ModifySuccessController {

	@FXML private Button accModBackBtn;

	/*
	 * Goes back to Account Modification window
	 * 
	 */
	@FXML public void goToAccountModification(ActionEvent event) {
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/AccountModification.fxml");
								
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
									
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	/*
	 * Changes the button color of the
	 * Back to Account Modification button
	 * 
	 */
	@FXML public void changeAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #67150e");
		accModBackBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Back to Account Modification button
	 * to its original color
	 * 
	 */
	@FXML public void revertAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #98eaf1");
		accModBackBtn.setTextFill(Color.BLACK);
	}


}
