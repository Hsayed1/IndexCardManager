package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.userData.SQLiteUserAccessor;
import application.databaseConnector.userData.SQLiteUserUpdater;
import application.databaseConnector.userData.UserDataAccessible;
import application.databaseConnector.userData.UserDataUpdatable;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class ModifyEmailController implements Initializable {

	private final static String DATABASE = "usersTest.db";
	
	@FXML private Button accModBackBtn;
	@FXML private Button submitBtn;
	@FXML private TextField newEmailInput;
	@FXML private Label errorLbl;
	
	/*
	 * Goes back to Account Modification Menu
	 * 
	 */
	@FXML public void goToAccountModification(ActionEvent event) {
		this.changeScene(event, "fxml/AccountModification.fxml");
	}
	
	/*
	 * Goes to Modification Success window
	 * 
	 */
	@FXML public void updateEmailOp(ActionEvent event) {
		
		// Gets input
		String newEmail = newEmailInput.getText();
		
		// Accesses database
		UserDataAccessible con = new SQLiteUserAccessor();
		
		// Checks to see if the text field is empty
		if (newEmailInput.getText().isEmpty()) {
			
			// Displays error if text field is empty
			errorLbl.setText("***The new email text field cannot be empty***");
			errorLbl.setVisible(true);
			return;
		} 
		
		// Checks to see if the email input does not conflict with
		// existing accounts
		if (con.findEmail(DATABASE, newEmail)) {
			
			// Displays error if input conflicts with existing accounts
			errorLbl.setText("****That email input is already associated with an existing account**");
			errorLbl.setVisible(true);
			return;
		}
		
		// Connects to database
		UserDataUpdatable con2 = new SQLiteUserUpdater();
		
		// Updates the database
		con2.updateEmail(DATABASE, newEmail);
		
		// Hides error label
		errorLbl.setVisible(false);
					
		// Changes scene to Modification Success window
		this.changeScene(event, "fxml/ModifySuccess.fxml");
	}
	
	/*
	 * Changes the button color of the
	 * Back to Account Modification button
	 * 
	 */
	@FXML public void changeAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #67150e");
		accModBackBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Back to Account Modification button
	 * to its original color
	 * 
	 */
	@FXML public void revertAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #98eaf1");
		accModBackBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the button color of the
	 * Submit button
	 * 
	 */
	@FXML public void changeSubmitColor() {
		submitBtn.setStyle("-fx-background-color: #67150e");
		submitBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Submit button to its original color
	 * 
	 */
	@FXML public void revertSubmitColor() {
		submitBtn.setStyle("-fx-background-color: #98eaf1");
		submitBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Changes the scene from one scene to another
	 * 
	 */
	private void changeScene(ActionEvent event, String fxml) {
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource(fxml);
						
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
							
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Hide error label
		errorLbl.setVisible(false);
		
	}
}
