Personal Index Card Manager Version 1.0 12/03/2022

== GENERAL INFORMATION ==
-------------------------



== GENERAL REQUIREMENTS ==
--------------------------

- This program requires an SQLite driver in order for the program to use its
  database. The driver will be provided, which is labeled "sqlite-jdbc-3.39.3.0.jar".
  To use this driver, a path must be built to it, and it must be part of the referenced
  libraries.

- This program also requires the use of a jar file that is labeled "passUtil-1.3.jar".

- If running on Eclipse, the program requires that both the src and resources folder
  be source folders in order for the code to locate the two folders.

== CONTRIBUTORS ==
------------------

Members:
 - Jonathan Chu
 - Hamed Sayed
 - Davis Tran
 - Nathan Kim

Team Number: #1


== OTHER INFORMATION ==
---------------------

SQLite driver link: https://mvnrepository.com/artifact/org.xerial/sqlite-jdbc

This is the driver that was used in order to use a SQLite database. 
The driver that was used is titled "sqlite-jdbc-3.39.3.0.jar." It uses
Version 3.39.3.0 and the jar file format. From here, a path was build to it
by adding an external jar. It should be part of the referenced libraries.

