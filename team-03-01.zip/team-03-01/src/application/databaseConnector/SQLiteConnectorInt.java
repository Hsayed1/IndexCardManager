package application.databaseConnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import application.personalIndexCardManager.IndexCard;

public interface SQLiteConnectorInt {

	/**
     * Connect to the desired database
     * in resources/database
     *
     * @return the Connection object
     */
    public default Connection connect(String database) {
    	
        // SQLite connection string for this project
        String url = "jdbc:sqlite:resources/database/" + database;
        Connection conn = null;
        
        try {
        	// Establishes a connection to the database
            conn = DriverManager.getConnection(url);
            //System.out.println("Connection to SQLite has been established");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
    
    /*
     * Get stored email input
     * 
     */
    public default String getStoredEmail(String database) {
    	
    	// Statement string to get email
    	// Gets the "active" or "logged in" email from the database
    	String sql = "SELECT EMAIL FROM GETEMAIL";
    	try {
    		// Connects to database and extracts stored email input
    		Connection con = this.connect(database);
    		Statement stmt  = con.createStatement();
    		
    		// Get the email input data from table
    		ResultSet rs = stmt.executeQuery(sql);
    		
    		// Checks to see if there is a stored email
    		if (rs.next()) {
    			String email = rs.getString("EMAIL");
    			con.close();
            	rs.close();
            	stmt.close();
    			return email;
    		}
    		// Closes connection and statement
    		con.close();
    		rs.close();
    		stmt.close();
    		
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    /*
     * Get current course name
     * 
     */
    public default String getCurrentCourse(String database) {
    	// Statement string to get email
    	// Gets the name of the course under the GetCourseName table
    	String sql = "SELECT CourseName FROM GetCourseName";
    	try {
    		// Connects to database and extracts stored email input
    		Connection con = this.connect(database);
    		Statement stmt  = con.createStatement();
    		
    		// Get the email input data from table
    		ResultSet rs = stmt.executeQuery(sql);
    		
    		// Checks to see if there is a stored email
    		if (rs.next()) {
    			String name = rs.getString("CourseName");
    			con.close();
            	rs.close();
            	stmt.close();
    			return name;
    		}
    		// Closes connection and statement
    		con.close();
    		rs.close();
    		stmt.close();
    		
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    /*
     * Get current course name
     * 
     */
    public default IndexCard getCurrentIndexCard(String database) {
    	// Statement string to get email
    	// Gets the name of the course under the GetCourseName table
    	String sql = "SELECT currentTerm, currentDefinition, currentLearned FROM GetCurrentIndexCard";
    	try {
    		// Connects to database and extracts stored email input
    		Connection con = this.connect(database);
    		Statement stmt  = con.createStatement();
    		
    		// Get the email input data from table
    		ResultSet rs = stmt.executeQuery(sql);
    		
    		// Checks to see if there is a stored index card
    		if (rs.next()) {
    			IndexCard ic = new IndexCard(rs.getString("currentTerm"), 
    					rs.getString("currentDefinition"),
    					this.getCurrentCourse(database),
    					rs.getInt("currentLearned") == 1);
    			
    			// Closes connection, statement, and result set
    			con.close();
            	rs.close();
            	stmt.close();
    			return ic;
    		}
    		// Closes connection and statement
    		con.close();
    		rs.close();
    		stmt.close();
    		
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    /*
     * Removes the stored email in the table
     * GETEMAIL from the database
     * 
     */
    public default void removeStoredEmail(String database) {
    	// PreparedStatement string to remove a piece of data from database table
    	String sql = "DELETE FROM GETEMAIL";
    	try {
    		// Connects to database and prepares a statement to remove data
    		Connection con = this.connect(database);
    		PreparedStatement statement = con.prepareStatement(sql);
    		
    		// updates table GETEMAIL
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		con.close();
    		statement.close();
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    /*
     * Removes the stored current course in the table
     * GetCourseName from the database
     * 
     */
    public default void removeCurrentCourse(String database) {
    	// PreparedStatement string to remove a piece of data from database table
    	String sql = "DELETE FROM GetCourseName";
    	try {
    		// Connects to database and prepares a statement to remove data
    		Connection con = this.connect(database);
    		PreparedStatement statement = con.prepareStatement(sql);
    		
    		// updates table GetCourseName
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		con.close();
    		statement.close();
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    /*
     * Removes the current index card from the table
     * GetIndexCard from the database
     * 
     */
    public default void removeCurrentIndexCard(String database) {
    	// PreparedStatement String to remove the "active" index card from 
    	// the database
    	String sql = "DELETE FROM GetCurrentIndexCard";
    	try {
    		//Connects to database and prepares a statement to remove the data
    		Connection con = this.connect(database);
    		PreparedStatement stmt = con.prepareStatement(sql);
    		
    		// updates the table GetIndexCard
    		stmt.executeUpdate();
    		
    		// Closes connection and statement to 
    		// prevent leaks in the background
    		con.close();
    		stmt.close();
    		
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
}
