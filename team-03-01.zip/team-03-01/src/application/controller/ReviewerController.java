package application.controller;

import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class ReviewerController implements Initializable 
{
	private final static String DATABASE = "usersTest.db";
	
	@FXML private Label Term;
	@FXML private Label Definition;
	@FXML private Label errorMessage;
	@FXML private CheckBox theCheckBox;
	
	private IndexCard currentCard;
	private List<IndexCard> allCards;
	private int numOfCards;
	private int currentCardNumber;

	@FXML public void showDefOp() {
		Definition.setText("Definition: " + currentCard.getDefinition());
		Definition.setVisible(true);
	}

	@FXML public void nextCardOp() {
		if(ReviewCardsController.getSelection().equals("Review learned"))
			nextLearnedCard();
		else if(ReviewCardsController.getSelection().equals("Review unlearned")) 
			nextUnlearnedCard();
		else
			nextCard();
		}

	@FXML public void checkBoxOp() {
		// Connects to database
		IndexCardDataInt con = new SQLiteIndexCard();
		
		// Checks to see if check box is checked
		if(theCheckBox.isSelected()) {
			this.currentCard.setIsLearned(1);
			theCheckBox.setText("Uncheck to unlearn");
			theCheckBox.setSelected(true);
			theCheckBox.setVisible(true);
		}
		else {
			this.currentCard.setIsLearned(0);
			theCheckBox.setText("Check to learn");
			theCheckBox.setSelected(false);
			theCheckBox.setVisible(true);	
		}
		
		// Updates current index card to be learned or not learned
		con.updateIsLearned(DATABASE, theCheckBox.isSelected());
	}
	
	@FXML public void backOp(ActionEvent event) {
		URL url = getClass().getClassLoader().getResource("fxml/ReviewCards.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		// sets error invisible
		errorMessage.setVisible(false);
		
		// connects to database
		IndexCardDataInt con = new SQLiteIndexCard();
	
		// Gets all index cards associated with the current course & other settings
		this.allCards = con.getIndexCards(DATABASE);
		numOfCards = allCards.size();
		currentCardNumber = 0;
		
		// Shuffles list of index cards
		Collections.shuffle(allCards);
		
		for (IndexCard ic : allCards)
			System.out.println(ic.toString());
		
		// Checks selection to see which index cards are needed to be reviewed
		if(ReviewCardsController.getSelection().equals("Review learned"))
			reviewLearned();
		else if(ReviewCardsController.getSelection().equals("Review unlearned"))
			reviewUnlearned();
		else
			reviewAll();
		
	}
	
	/*
	 * Review all index cards
	 * 
	 */
	private void reviewAll() {
		// Connect to database
		IndexCardDataInt con = new SQLiteIndexCard();
		
		// Gets first card
		currentCard = allCards.get(currentCardNumber);
		
		// Stores current card as "active" card for potential of updating
		// the isLearned check box
		con.storeCurrentIndexCard(DATABASE, currentCard);
		
		// Checks to see if the card is not null
		if(currentCard != null) {
			
			// Sets up first index card to display all relevant information
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			if(currentCard.getIsLearned() == true) {
				theCheckBox.setText("Uncheck to unlearn");
				theCheckBox.setSelected(true);
				theCheckBox.setVisible(true);
			}
			else
			{
				theCheckBox.setText("Check to learn");
				theCheckBox.setSelected(false);
				theCheckBox.setVisible(true);
			}
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
	}
	
	/*
	 * Review all learned index cards
	 * 
	 */
	private void reviewLearned() {
		// Connect to database
		IndexCardDataInt con = new SQLiteIndexCard();
		
		// Gets first index card
		currentCard = allCards.get(currentCardNumber);
			
		if (currentCard.getIsLearned() == true) {
			// Stores current card as "active" card for potential of updating
			// the isLearned check box
			con.storeCurrentIndexCard(DATABASE, currentCard);
		}
		
		while(currentCard.getIsLearned() != true)
		{
			currentCardNumber++;
			if(currentCardNumber >= allCards.size())
			{
				errorMessage.setText("*All cards have been reviewed*");
				errorMessage.setVisible(true);
				break;
			}
			currentCard = allCards.get(currentCardNumber);
			
			if (currentCard.getIsLearned() == true) {
				// Stores current card as "active" card for potential of updating
				// the isLearned check box
				con.storeCurrentIndexCard(DATABASE, currentCard);
			}
		}
		
		// Sets up first index card & checks to see if the index card is not null
		if(currentCard != null) {
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			theCheckBox.setText("Uncheck to unlearn");
			theCheckBox.setSelected(true);
			theCheckBox.setVisible(true);
		}
		else {
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
	}
	
	/*
	 * Reviews all not learned index cards
	 * 
	 */
	private void reviewUnlearned() {
		// Connect to database
		IndexCardDataInt con = new SQLiteIndexCard();
				
		// Gets first index card
		currentCard = allCards.get(currentCardNumber);
		
		// Checks to see if the index card is not learned
		if (currentCard.getIsLearned() == false) {
			// Stores current card as "active" card for potential of updating
			// the isLearned check box
			con.storeCurrentIndexCard(DATABASE, currentCard);
		}
				
		// Gets first not learned index card
		while(currentCard.getIsLearned() == true) {
			
			// Goes to next card
			currentCardNumber++;
			
			// Checks to see if the index count reaches max size of the list of index cards
			if(currentCardNumber >= allCards.size())
			{
				errorMessage.setText("*All cards have been reviewed*");
				errorMessage.setVisible(true);
				break; // exits loop
			}
			
			// Gets next card
			currentCard = allCards.get(currentCardNumber);
			
			// Checks to see if the current index card is not learned
			// in order to store as an "active" card
			if (currentCard.getIsLearned() == false) {
				// Stores current card as "active" card for potential of updating
				// the isLearned check box
				con.storeCurrentIndexCard(DATABASE, currentCard);
			}
		}
		
		// Checks to see if the index card is null
		if(currentCard != null)
		{
			// Displays all information from the index card
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			theCheckBox.setText("Check to learn");
			theCheckBox.setSelected(false);
			theCheckBox.setVisible(true);
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
	}
	
	/*
	 * Goes to the next "learned" card in the list
	 * 
	 */
	private void nextLearnedCard() {
		
		// Goes to next card
		currentCardNumber++;
		
		// Checks to see if the current card number is less than
		// total number of cards
		if (currentCardNumber < numOfCards)
		{
			// Connect to database
			IndexCardDataInt con = new SQLiteIndexCard();
			
			// Uses temp to go through the index cards
			IndexCard temp = allCards.get(currentCardNumber);
			
			// Checks to see if current index card is learned
			if (temp.getIsLearned() == true) {
				currentCard = temp;
				// Stores current card as "active" card for potential of updating
				// the isLearned check box
				con.storeCurrentIndexCard(DATABASE, currentCard);
			}
			
			// Goes through the list of index cards
			while(temp.getIsLearned() != true)
			{
				// Goes to next card
				currentCardNumber++;
				
				// Checks to see if the number of cards counts exceeds
				// or equals the max number of cards
				if(currentCardNumber >= numOfCards )
				{
					errorMessage.setText("*All cards have been reviewed*");
					errorMessage.setVisible(true);
					break; // exits loop
				}
				
				// Goes to next next card
				temp = allCards.get(currentCardNumber);
				
				// checks to see if the learned status of the temp card is learned/true
				if (temp.getIsLearned() == true) {
					// Stores current card to temp card that is learned
					currentCard = temp;
					
					// Stores current card as "active" card for potential of updating
					// the isLearned check box
					con.storeCurrentIndexCard(DATABASE, currentCard);
				}
			}
			
			// Updates settings to current index card that is learned
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);
			theCheckBox.setText("Uncheck to unlearn");
			theCheckBox.setSelected(true);
			theCheckBox.setVisible(true);
		}
		else {
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}
	}
	
	/*
	 * Goes to next not learned index card in the list
	 * 
	 */
	private void nextUnlearnedCard() {
		
		// Goes to next card
		currentCardNumber++;
				
		// Checks to see if the current card number is less than
		// total number of cards
		if (currentCardNumber < numOfCards)
		{
			// Connect to database
			IndexCardDataInt con = new SQLiteIndexCard();
					
			// Uses temp to go through the index cards
			IndexCard temp = allCards.get(currentCardNumber);
					
			// Checks to see if current index card is not learned
			if (temp.getIsLearned() == false) {
				// sets current card to next not learned card
				// if temp is not learned
				currentCard = temp;
				
				// Stores current card as "active" card for potential of updating
				// the isLearned check box
				con.storeCurrentIndexCard(DATABASE, currentCard);
			}
					
			// Goes through the list of index cards until it finds a not learned
			// index card
			while(temp.getIsLearned() == true)
			{
				// Goes to next card
				currentCardNumber++;
						
				// Checks to see if the number of cards counts exceeds
				// or equals the max number of cards
				if(currentCardNumber >= numOfCards )
				{
					errorMessage.setText("*All cards have been reviewed*");
					errorMessage.setVisible(true);
					break; // exits loop
				}
						
				// Goes to next next card
				temp = allCards.get(currentCardNumber);
						
				// checks to see if the learned status of the temp card is not learned or false
				if (temp.getIsLearned() == false) {
					// Stores current card to temp card that is learned
					currentCard = temp;
							
					// Stores current card as "active" card for potential of updating
					// the isLearned check box
					con.storeCurrentIndexCard(DATABASE, currentCard);
				}
		}
					
			// Updates settings to current index card that is not learned
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);
			theCheckBox.setText("Check to learn");
			theCheckBox.setSelected(false);
			theCheckBox.setVisible(true);
		}
		else {
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}
		
	}
	
	/*
	 * Checks next card regardless of learned status
	 * 
	 */
	private void nextCard()
	{
		// Goes to next card
		currentCardNumber++;
		
		// Checks to see if current card count is less than max card count
		if (currentCardNumber < numOfCards)
		{
			// Connect to database
			IndexCardDataInt con = new SQLiteIndexCard();
			
			// Gets the next card
			currentCard = allCards.get(currentCardNumber);
			
			// Stores current card as "active" card for potential of updating
			// the isLearned check box
			con.storeCurrentIndexCard(DATABASE, currentCard);
			
			// Updates display settings to display all relevant information of index
			// card
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);	
			
			// Sets the check box up to see if the current card is learned or not learned
			if(currentCard.getIsLearned() == true)
			{
				theCheckBox.setText("Uncheck to unlearn");
				theCheckBox.setSelected(true);
				theCheckBox.setVisible(true);
			}
			else
			{
				theCheckBox.setText("Check to learn");
				theCheckBox.setSelected(false);
				theCheckBox.setVisible(true);
			}
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}
	}

}
