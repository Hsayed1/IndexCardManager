package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.Label;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.userData.SQLiteUserUpdater;
import application.databaseConnector.userData.UserDataUpdatable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

public class ModifySecurityController implements Initializable {

	private final static String DATABASE = "usersTest.db";
	
	@FXML private Button accModBackBtn;
	@FXML private Button submitBtn;
	@FXML private ComboBox<String> secQuestionCB;
	@FXML private TextField newSecAnsInput;
	@FXML private Label errorLbl;
	
	/*
	 * Goes back to Account Modification Menu
	 * 
	 */
	@FXML public void goToAccountModification(ActionEvent event) {
		this.changeScene(event, "fxml/AccountModification.fxml");
	}
	
	/*
	 * Updates security question and answer
	 * 
	 */
	@FXML public void updateSecurityOp(ActionEvent event) {
		
		// Checks to see if text field is empty or security question is selected
		if (newSecAnsInput.getText().isEmpty() || secQuestionCB.getValue() == null) {
			// Displays error if text field is empty
			errorLbl.setText("***Please select a question and/or make sure that the field is filled***");
			errorLbl.setVisible(true);
			return;
		}
		
		// Gets security question and answer
		String secQuest = secQuestionCB.getSelectionModel().getSelectedItem().toString();
		String secAns = newSecAnsInput.getText().toLowerCase();
		
		// Connects to database
		UserDataUpdatable con = new SQLiteUserUpdater();
		
		// Updates security question and answer
		con.updateSecurity(DATABASE, secQuest, secAns);
		
		this.changeScene(event, "fxml/ModifySuccess.fxml");
	}

	/*
	 * Changes the button color of the
	 * Back to Account Modification button
	 * 
	 */
	@FXML public void changeAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #67150e");
		accModBackBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Back to Account Modification button
	 * to its original color
	 * 
	 */
	@FXML public void revertAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #98eaf1");
		accModBackBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the button color of the
	 * Submit button
	 * 
	 */
	@FXML public void changeSubmitColor() {
		submitBtn.setStyle("-fx-background-color: #67150e");
		submitBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Submit button to its original color
	 * 
	 */
	@FXML public void revertSubmitColor() {
		submitBtn.setStyle("-fx-background-color: #98eaf1");
		submitBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Changes the scene from one scene to another
	 * 
	 */
	private void changeScene(ActionEvent event, String fxml) {
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource(fxml);
						
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
							
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Hide error label
		errorLbl.setVisible(false);
		
		// list of questions
		ObservableList<String> list = 
				FXCollections.observableArrayList(
						"What is your favorite video game?",
						"What was the name of your elementary school?",
						"What is your favorite food?",
						"What is your favorite school subject?",
						"Who is your favorite music artist?");
				
		secQuestionCB.setItems(list);
		
	}
}
