package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.courseData.SQLiteCourseAccessor;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class CreateIndexCardController implements Initializable {
	
	private final static String DATABASE = "usersTest.db";
	
	@FXML private TextField termTextField;
	@FXML private TextField definitionTextField;
	@FXML private Button doneButton;
	@FXML private Label errorLbl;
	@FXML private Button backBtn;
	
	
	@FXML public void Done(ActionEvent event) {
		String term = termTextField.getText();
		String definition = definitionTextField.getText();
		
		
		// Stage 1: Initialize connection with the database 
		IndexCardDataInt con = new SQLiteIndexCard();
		SQLiteConnectorInt con2 = new SQLiteCourseAccessor();
		
		IndexCard ic = new IndexCard(term, definition, con2.getCurrentCourse(DATABASE));
		
		if(con.checkIdenticalIC(DATABASE, ic)) {
			errorLbl.setText("***There exists an index card with the exact same term and definition***");
			errorLbl.setVisible(true);
			return;
		}
		errorLbl.setVisible(false);
		// Stage 2: Add course to the database
		//(Finished) 	1) I need to create an index card class inside the personalIndexCardManager
		//(In Progress) 2) Create an addIndexCard function inside SQLConnector.java
		con.addIndexCard(DATABASE, ic);
		Stage stage = (Stage)doneButton.getScene().getWindow();
		stage.close();
		Main m = new Main();
		m.changeScene("fxml/IndexCard.fxml");
	}

	/*
	 * Exits Create Index Card window
	 * 
	 */
	@FXML public void backToICPanel(ActionEvent event) {
		// Closes prompt and returns to index card panel
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.close();
		Main m = new Main();
		m.changeScene("fxml/IndexCard.fxml");
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		errorLbl.setVisible(false);	
		
		// Button settings to mostly change colors for back button
		backBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> backBtn.setStyle("-fx-background-color: #df5461"));
		backBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> backBtn.setStyle("-fx-background-color: #20ab9e"));
		
		// Button settings to mostly change colors for done button
		doneButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doneButton.setStyle("-fx-background-color: #64e000"));
		doneButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doneButton.setTextFill(Color.BLACK));
		doneButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> doneButton.setStyle("-fx-background-color: #9b1fff"));
		doneButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> doneButton.setTextFill(Color.WHITE));
	}


}
