package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.CheckBox;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class DeleteIndexCardController implements Initializable {
	
	private static final String DATABASE = "usersTest.db";

	@FXML private Label errorLbl;
	@FXML private CheckBox deleteAffirmCB;
	@FXML private Button deleteICBtn;
	@FXML private Button backBtn;

	/*
	 * deletes the index card
	 */
	@FXML public void deleteIC(ActionEvent event) {
		// Checks to see if check box is checked
		if (!(deleteAffirmCB.isSelected())) {
			errorLbl.setText("***You must check the box to delete the index card***");
			errorLbl.setVisible(true);
			return;
		}
		errorLbl.setVisible(false);
		
		// Connects to database
		IndexCardDataInt con = new SQLiteIndexCard();
		SQLiteConnectorInt con2 = new SQLiteIndexCard();
		
		// Deletes the index card
		con.deleteIndexCard(DATABASE, new IndexCard(con2.getCurrentIndexCard(DATABASE).getTerm(),
				con2.getCurrentIndexCard(DATABASE).getDefinition(),
				con2.getCurrentIndexCard(DATABASE).getParentCourse(),
				con2.getCurrentIndexCard(DATABASE).getIsLearned()));
		
		// Closes prompt and returns to index card panel
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.close();
		Main m = new Main();
		m.changeScene("fxml/IndexCard.fxml"); // updates panel
	}

	/*
	 * Goes back to index card modification window
	 * 
	 */
	@FXML public void backToModIC(ActionEvent event) {
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/ModifyIndexCard.fxml");
										
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
									
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Hides error tag
		errorLbl.setVisible(false);

		// Button settings (mostly for color change) for delete button
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> deleteICBtn.setStyle("-fx-background-color: #f9deb6;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> deleteICBtn.setTextFill(Color.BLACK));
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> deleteICBtn.setStyle("-fx-background-color: #062149;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> deleteICBtn.setTextFill(Color.WHITE));
		
		// Button settings (mostly for color change) for back button
		backBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> backBtn.setStyle("-fx-background-color: #f9deb6;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		backBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> backBtn.setTextFill(Color.BLACK));
		backBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> backBtn.setStyle("-fx-background-color: #062149;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		backBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> backBtn.setTextFill(Color.WHITE));
	}
}
