package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import application.Main;
import javafx.event.ActionEvent;

public class AccountModificationController {

	@FXML private Button accManBackBtn;
	@FXML private Button modEmailBtn;
	@FXML private Button modPassBtn;
	@FXML private Button modSecBtn;
	
	/*
	 * Goes back to Account Management
	 * 
	 */
	@FXML public void goToAccountManagement(ActionEvent event) {
		Stage stage = (Stage)accManBackBtn.getScene().getWindow();
		stage.close();
		
		// Updates menu
		Main m = new Main();
		m.changeScene("fxml/AccountManagement.fxml");
	}
	
	/*
	 * Goes to Email Modification
	 * 
	 */
	@FXML public void goToEmailMod(ActionEvent event) {
		this.changeScene(event, "fxml/ModifyEmail.fxml");
	}
	
	/*
	 * Goes to Password Modification
	 * 
	 */
	@FXML public void goToPassMod(ActionEvent event) {
		this.changeScene(event, "fxml/ModifyPassword.fxml");
	}
	
	/*
	 * Goes to Security Modification
	 * 
	 */
	@FXML public void goToSecMod(ActionEvent event) {
		this.changeScene(event, "fxml/ModifySecurity.fxml");
	}
	
	/*
	 * Changes the button color of the
	 * Modify Email button
	 * 
	 */
	@FXML public void changeModEmailColor() {
		modEmailBtn.setStyle("-fx-background-color: #67150e");
		modEmailBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Modify Email button to its original
	 * 
	 */
	@FXML public void revertModEmailColor() {
		modEmailBtn.setStyle("-fx-background-color: #98eaf1");
		modEmailBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the button color of the
	 * Back to Account Management button
	 * 
	 */
	@FXML public void changeAccManColor() {
		accManBackBtn.setStyle("-fx-background-color: #67150e");
		accManBackBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Back to Account Management button
	 * to its original
	 * 
	 */
	@FXML public void revertAccManColor() {
		accManBackBtn.setStyle("-fx-background-color: #98eaf1");
		accManBackBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the button color of the
	 * Modify Password button
	 * 
	 */
	@FXML public void changePassModColor() {
		modPassBtn.setStyle("-fx-background-color: #67150e");
		modPassBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the 
	 * Modify Password button to its original
	 * 
	 */
	@FXML public void revertPassModColor() {
		modPassBtn.setStyle("-fx-background-color: #98eaf1");
		modPassBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the button color of the
	 * Modify Security Question and Answer
	 * button
	 * 
	 */
	@FXML public void changeSecModColor() {
		modSecBtn.setStyle("-fx-background-color: #67150e");
		modSecBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Modify Security Question and Answer
	 * button to its original
	 * 
	 */
	@FXML public void revertSecModColor() {
		modSecBtn.setStyle("-fx-background-color: #98eaf1");
		modSecBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the scene from one scene to another
	 * 
	 */
	private void changeScene(ActionEvent event, String fxml) {
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource(fxml);
						
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
							
		} catch (IOException e){
			e.printStackTrace();
		}
	}

}
