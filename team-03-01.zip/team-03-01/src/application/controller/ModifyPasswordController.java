package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.Label;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.userData.SQLiteUserUpdater;
import application.databaseConnector.userData.UserDataUpdatable;
import javafx.event.ActionEvent;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

public class ModifyPasswordController implements Initializable {

	private final static String DATABASE = "usersTest.db";
	
	@FXML private Button accModBackBtn;
	@FXML private Button submitBtn;
	@FXML private PasswordField passInputField;
	@FXML private Label errorLbl;
	@FXML private CheckBox displayPassword;
	@FXML private TextField passInputField2;
	
	/*
	 * Goes back to Account Modification Menu
	 * 
	 */
	@FXML public void goToAccountModification(ActionEvent event) {
		this.changeScene(event, "fxml/AccountModification.fxml");
	}
	
	/*
	 * Updates the password
	 * 
	 */
	@FXML public void updatePasswordOp(ActionEvent event) {
				
		// Checks to see if the text field is empty
		if (passInputField.getText().isEmpty()) {
					
			// Displays error if text field is empty
			errorLbl.setText("***The password field cannot be empty***");
			errorLbl.setVisible(true);
			return;
		} 
		
		// Gets new password
		String newPassword = passInputField.getText();
				
		// Connects to database
		UserDataUpdatable con = new SQLiteUserUpdater();
				
		// Updates the database
		con.updatePassword(DATABASE, newPassword);
		
		// Hides error label
		errorLbl.setVisible(false);
							
		// Changes scene to Modification Success window
		this.changeScene(event, "fxml/ModifySuccess.fxml");
	}
	
	/*
	 * Displays password
	 * 
	 */
	@FXML public void displayPassword() {
		// Binds Visible password field to when displayPassword is checked
		passInputField2.managedProperty().bind(displayPassword.selectedProperty());
		passInputField2.visibleProperty().bind(displayPassword.selectedProperty());
		
		// Binds Masked password field to when displayPassword is not checked
		passInputField.managedProperty().bind(displayPassword.selectedProperty().not());
		passInputField.visibleProperty().bind(displayPassword.selectedProperty().not());
		
		// Binds the text values of the visible password field and masked password field 
		// to be bidirectional. Both fields will display the same password
		passInputField2.textProperty().bindBidirectional(passInputField.textProperty());
	}
	
	/*
	 * Changes the button color of the
	 * Back to Account Modification button
	 * 
	 */
	@FXML public void changeAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #67150e");
		accModBackBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Back to Account Modification button
	 * to its original color
	 * 
	 */
	@FXML public void revertAccModColor() {
		accModBackBtn.setStyle("-fx-background-color: #98eaf1");
		accModBackBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the button color of the
	 * Submit button
	 * 
	 */
	@FXML public void changeSubmitColor() {
		submitBtn.setStyle("-fx-background-color: #67150e");
		submitBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts the button color of the
	 * Submit button to its original color
	 * 
	 */
	@FXML public void revertSubmitColor() {
		submitBtn.setStyle("-fx-background-color: #98eaf1");
		submitBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Changes the scene from one scene to another
	 * 
	 */
	private void changeScene(ActionEvent event, String fxml) {
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource(fxml);
						
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
							
		} catch (IOException e){
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Hide error label
		errorLbl.setVisible(false);
		
		// Hide TextField
		passInputField2.setVisible(false);
		passInputField2.setManaged(false);
		
	}

}
