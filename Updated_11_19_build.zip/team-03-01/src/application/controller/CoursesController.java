package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.courseData.*;
import application.databaseConnector.userData.SQLiteUserAccessor;
import application.personalIndexCardManager.Course;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CoursesController implements Initializable {

	private final static String DATABASE = "usersTest.db";
	
	@FXML private Button accntManageBtn;
	@FXML private Button logoutBtn;
	@FXML private BorderPane loginScene;
	@FXML private Button createCourseBtn;
	@FXML private FlowPane coursesPanel;
	@FXML private ScrollPane scrollPane;

	@FXML public void logout(ActionEvent event) {
		
		// "Logs out" from the "active" email
		SQLiteConnectorInt con = new SQLiteUserAccessor();
		con.removeStoredEmail(DATABASE);
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/Home.fxml");
								
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	@FXML public void goToAccMan(ActionEvent event) {
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/AccountManagement.fxml");
										
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
										
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * Creates new course
	 * 
	 */
	@FXML public void createNewCourse(ActionEvent event) {
		try {
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("fxml/CourseCreation.fxml"));
			// Settings for the security question prompt
			primaryStage.setTitle("Create a Course");
			primaryStage.setScene(new Scene(root, 500, 300));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}

	/*
	 * Change create course button color when mouse hovers
	 * over the button
	 * 
	 */
	@FXML public void changeNewCourseBtnColor() {
		createCourseBtn.setStyle("-fx-background-color: #e5938a");
		createCourseBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Reverts create course button color when mouse exits
	 * the button
	 * 
	 */
	@FXML public void revertNewCourseBtnColor() {
		createCourseBtn.setStyle("-fx-background-color: #1a6c75");
		createCourseBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Change logout button color when mouse hovers
	 * over the button
	 * 
	 */
	@FXML public void changeLogoutBtnColor() {
		logoutBtn.setStyle("-fx-background-color: #06014a");
		logoutBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts logout button color when mouse exits
	 * the button
	 * 
	 */
	@FXML public void revertLogoutBtnColor() {
		logoutBtn.setStyle("-fx-background-color: #F9FEB5");
		logoutBtn.setTextFill(Color.BLACK);
	}
	
	/*
	 * Changes the Account Management button
	 * color to its inverse
	 * 
	 */
	@FXML public void changeAccManColor() {
		accntManageBtn.setStyle("-fx-background-color: #06014a");
		accntManageBtn.setTextFill(Color.WHITE);
	}

	/*
	 * Reverts the Account Management button color
	 * back to its original color
	 * 
	 */
	@FXML public void revertAccManColor() {
		accntManageBtn.setStyle("-fx-background-color: #F9FEB5");
		accntManageBtn.setTextFill(Color.BLACK);
	}
	
	private Button newCourses(String name) {
		Button btn = new Button();
		btn.setText(name);
		return btn;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		// Connects to database concerning course data
		CourseDataAccessible con1 = new SQLiteCourseAccessor();
		CourseDataUpdatable con2 = new SQLiteCourseUpdater();
		
		// Adds all courses associated with the
		// "logged in" account to the courses page
		for (Course c: con1.getCourses(DATABASE)) {
			Button newCourse = newCourses(c.getName());
			
			// Allows each course to access its own set of index cards
			newCourse.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                Main m = new Main();
	                con2.storeCurrentCourse(DATABASE, c);
	                m.changeScene("fxml/IndexCard.fxml");
	            }
	        });
			
			// Button settings
			newCourse.setFont(Font.font(24));
			
			// Displays all courses associated with account
			coursesPanel.getChildren().add(newCourse);
		}
		
		
	}


}
