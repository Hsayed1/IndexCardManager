package application.controller;

import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.awt.Checkbox;
import java.awt.Desktop.Action;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class ReviewerController implements Initializable 
{
	private final static String DATABASE = "usersTest.db";
	
	@FXML private Label Term;
	@FXML private Label Definition;
	@FXML private Label errorMessage;
	
	private IndexCard currentCard;
	private List<IndexCard> allCards;
	private int numOfCards;
	private int currentCardNumber;

	@FXML public void showDefOp() {
		if(currentCardNumber <= numOfCards)
		{
			Definition.setText("Definition: " + currentCard.getDefinition());
			Definition.setVisible(true);
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}		
	}

	@FXML public void nextCardOp() {
		currentCardNumber++;
		if (currentCardNumber < numOfCards)
		{
			currentCard = allCards.get(currentCardNumber);
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
			Definition.setText("Definition: ???");
			Definition.setVisible(true);	
		}
		else
		{
			errorMessage.setText("*All cards have been reviewed*");
			errorMessage.setVisible(true);
		}	
	}

	
	@FXML public void backOp(ActionEvent event) {
		URL url = getClass().getClassLoader().getResource("fxml/ReviewCards.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		String selection = ReviewCardsController.getSelection();
		
		
		errorMessage.setVisible(false);
		IndexCardDataInt con = new SQLiteIndexCard();
		
		//temporary tester to test this class           DELETE WHEN INDEX CARD FUNCTION WORKS
		this.allCards = createTester();
		if(selection.equals("Review learned"))
		{
			for(IndexCard i : allCards)
			{
				if(i.getIsLearned() == false)
					allCards.remove(i);
			}
		}
		if(selection.equals("Review unlearned"))
		{
			for(IndexCard i : allCards)
			{
				if(i.getIsLearned() == true)
					allCards.remove(i);
			}
		}
		numOfCards = allCards.size();
		currentCardNumber = 0;
		currentCard = allCards.get(currentCardNumber);

		if(currentCard != null)
		{
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
		
		
		//UNCOMMENT WHEN INDEX CARD CLASS FUNCTION IS WORKING
		/**
		this.allCards = con.getIndexCards(DATABASE);
		numOfCards = allCards.size();
		currentCardNumber = 0;
		currentCard = allCards.get(currentCardNumber);

		if(currentCard != null)
		{
			Term.setText("Term: " + currentCard.getTerm());
			Term.setVisible(true);
		}
		else
		{
			errorMessage.setText("*There are no cards to study*");
			errorMessage.setVisible(true);
		}
		*/
	}
	
	//temporary tester
	public List<IndexCard> createTester()
	{
		ArrayList result = new ArrayList();
		
		IndexCard card1 = new IndexCard("Test term 1", "Test defintion 1", "Math", false);
		result.add(card1);
		
		IndexCard card2 = new IndexCard("Test term 2", "Test defintion 2", "Math", false);
		result.add(card2);
		
		IndexCard card3 = new IndexCard("Test term 3", "Test defintion 3", "Math", false);
		result.add(card3);
		
		return result;
		
	}

}
