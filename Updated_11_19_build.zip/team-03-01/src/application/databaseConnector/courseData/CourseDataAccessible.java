package application.databaseConnector.courseData;

import java.util.List;

import application.personalIndexCardManager.Course;

public interface CourseDataAccessible {

	List<Course> getCourses(String database);
	
	boolean checkName(String database, String name);

}