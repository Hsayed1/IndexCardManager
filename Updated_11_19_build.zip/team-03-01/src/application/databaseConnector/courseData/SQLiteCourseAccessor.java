package application.databaseConnector.courseData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.databaseConnector.SQLiteConnectorInt;
import application.personalIndexCardManager.Course;

public class SQLiteCourseAccessor implements SQLiteConnectorInt, CourseDataAccessible {

    /*
     * Gets the courses of the specified email
     * 
     * @param database the name of the database
     * @return a list of courses associated with the "active" account
     */
	@Override
    public List<Course> getCourses(String database) {
    	// Gets list of courses
    	List<Course> courses = new ArrayList<Course>();
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	// the active email
    	String sql = "SELECT email, courseName FROM Courses WHERE email = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the "active" email that is being used
    		// for login purposes
    		String email = this.getStoredEmail(database);
    		System.out.println("Got " + email);
    		statement.setString(1, email);
    		
    		// Pulls all courses from the database
    		// that belong to the "logged in" email
    		ResultSet rs  = statement.executeQuery();
    		while(rs.next()) {
    			courses.add(new Course(rs.getString("courseName")));
    		}
    		
    		// Closes connection, result set, and statement
    		con.close();
    		rs.close();
    		statement.close();
    		return courses;
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return null;
    	
    }
	
    /*
     * Checks if name is already taken
     * 
     * @param database the name of the database
     * @param name the course name input
     */
	@Override
    public boolean checkName(String database, String name) {
    	// PreparedStatement where it pulls a piece of data that matches
    	// with the desired course name from the database
    	String sql = "SELECT courseName,courseID FROM Courses WHERE courseName = ? and courseID = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Fills the designated parameters formed by sql String
    		// Statement tries to find all data with the corresponding
    		// course name and course ID
    		statement.setString(1, name);
    		Course temp = new Course(name);
    		System.out.println(this.getStoredEmail(database) + "#" + temp.getID());
    		statement.setString(2, this.getStoredEmail(database) + "#" + temp.getID());
    		
    		
    		// Check if course is found in the database
    		ResultSet rs  = statement.executeQuery();
    		if (rs.next()) {
                System.out.println(rs.getString("courseName") + "\t"
                		+ rs.getString("courseID"));
                
                // Closes the connection, statement, and result set
                // to prevent background leakages
                con.close();
        		statement.close();
        		rs.close();
                return true;
            }
    		
    		// Closes the connection, statement, and result set
            // to prevent background leakages
    		con.close();
    		statement.close();
    		rs.close();
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return false;
    }
}
