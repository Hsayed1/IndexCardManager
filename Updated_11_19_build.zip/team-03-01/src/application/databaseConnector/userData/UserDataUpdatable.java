package application.databaseConnector.userData;

import application.personalIndexCardManager.User;

public interface UserDataUpdatable {

	void addUser(String database, User user);
	
	void storeEmailInput(String database, String emailInput);
	
	void updateEmail(String database, String newEmail);

	void updatePassword(String database, String newPassword);
	
	void updateSecurity(String database, String newSecurityQuestion, String newSecurityAnswer);
	
	void deleteUser(String database);
}
