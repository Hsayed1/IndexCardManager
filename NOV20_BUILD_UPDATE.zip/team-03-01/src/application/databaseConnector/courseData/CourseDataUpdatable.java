package application.databaseConnector.courseData;

import application.personalIndexCardManager.Course;

public interface CourseDataUpdatable {

	void storeCurrentCourse(String database, Course currentCourse);

	void addCourse(String database, Course course);
	
	void updateCourseName(String database, Course newCourse);

	void deleteCourse(String database);
	
	void deleteAllCourses(String database);
}
