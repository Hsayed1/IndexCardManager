package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.net.URL;

import application.Main;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.Course;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;




public class CreateIndexCardController {
	
	private final static String DATABASE = "usersTest.db";
	
	@FXML TextField termTextField;
	@FXML TextField definitionTextField;
	@FXML Button doneButton;
	
	
	@FXML public void Done(ActionEvent event) {
		String term = termTextField.getText();
		String definition = definitionTextField.getText();
		
		
		// Stage 1: Initialize connection with the database 
		IndexCardDataInt con = new SQLiteIndexCard();
		
		// Stage 2: Add course to the database
		//(Finished) 	1) I need to create an index card class inside the personalIndexCardManager
		//(In Progress) 2) Create an addIndexCard function inside SQLConnector.java
		
		//con.addIndexCard(DATABASE, new IndexCard(name));
		//Stage stage = (Stage)doneButton.getScene().getWindow();
		//stage.close();
		//Main m = new Main();
		//m.changeScene("fxml/IndexCard.fxml");
	}
	

}
