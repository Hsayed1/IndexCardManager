package application.personalIndexCardManager;

import java.util.List;

public class Course {

	private String name;
	private List<String> indexCards;
	
	public Course(String name) {
		this.name = name;
	}
}
