package application.databaseConnector.userData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import application.databaseConnector.SQLiteConnectorInt;
import application.personalIndexCardManager.User;
import edu.sjsu.yazdankhah.crypto.util.PassUtil;

/*
 * This class handles data regarding users
 * 
 */
public class SQLiteUserAccessor implements SQLiteConnectorInt, UserDataAccessible {

    /*
     * Check database for the specified user
     * 
     * @param database the name of the database
     */
	@Override
    public List<User> getAllUsers(String database) {
    	
    	// List of users
    	List<User> users = new ArrayList<User>();
    	
    	// PreparedStatement where it pulls data from the specified table in the specified database
    	String sql = "SELECT email, password, securityQuest, securityAns FROM Users";
    	try {
    		Connection conn = this.connect(database);
    		Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
                
    		// loop through the result set
    		while (rs.next()) {
    			users.add(new User(rs.getString("email"),rs.getString("password"), rs.getString("securityQuest"), rs.getString("securityAns")));
    			System.out.println(rs.getString("email") +  "\t" + 
            		   rs.getString("password") + "\t" +
                       rs.getString("securityQuest") + "\t" +
                       rs.getString("securityAns"));
            }
            // Closes connection, result set, and statement
       		conn.close();
       		rs.close();
       		stmt.close();
       		return users;
               
        } catch (SQLException e) {
        	e.getStackTrace();
        }
   		return null;
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     * @param email the email input
     */
	@Override
    public boolean findEmail(String database, String email) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	// with the desired username from the database
    	String sql = "SELECT email FROM Users WHERE email = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the user with the desired email
    		statement.setString(1, email);
    		
    		// Check if user is found in the database
    		ResultSet rs  = statement.executeQuery();
    		if (rs.next()) {
                System.out.println(rs.getString("email"));
                
                // Closes connection, result set, and statement
           		con.close();
           		rs.close();
           		statement.close();
           		return true;
            }
    		// Closes connection, result set, and statement
       		con.close();
       		rs.close();
       		statement.close();
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return false;
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     * @param the email input
     * @param password the password input
     */
	@Override
    public boolean findPass(String database, String email, String password) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	// with the desired password in the specified database
		String sql = "SELECT password FROM Users WHERE email = ?";
		
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the user with the desired password
    		statement.setString(1, email);
    		
    		// Check if user is found in the database
    		ResultSet rs  = statement.executeQuery();
    		
    		// Retrieve user's encrypted password from database 
    		String encryptedPassword = rs.getString(1);
    		String decryptedPassword = new PassUtil().decrypt(encryptedPassword);
    		
    		System.out.println("Finding password...");
        	System.out.println("Password: " + password + " | " + encryptedPassword + " | " + decryptedPassword);
    		
    		if (rs.next() && password.equals(decryptedPassword)) {
                System.out.println(rs.getString("password"));
                // Closes connection, result set, and statement
        		con.close();
        		rs.close();
        		statement.close();
                return true;
            }
    		// Closes connection, result set, and statement
    		con.close();
    		rs.close();
    		statement.close();
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return false;
    }
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     */
	@Override
    public String getSecQuest(String database) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	String sql = "SELECT email, securityQuest FROM Users WHERE email = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the user's security question
    		String email = this.getStoredEmail(database);
    		System.out.println("Got " + email);
    		statement.setString(1, email);
    		
    		// Pulls data from the database
    		ResultSet rs  = statement.executeQuery();
    		
    		// Checks to see if it can get the specified data
    		if (rs.next()) {
                System.out.println(rs.getString("email") + "\t" +
                		rs.getString("securityQuest"));
                
                // Gets the security question associated with the email
                String secQuest = rs.getString("SecurityQuest");
                
                // Closes connection, result set, and statement
        		con.close();
        		rs.close();
        		statement.close();
                return secQuest;
            }
    		// Closes connection, result set, and statement
    		con.close();
    		rs.close();
    		statement.close();
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	}
    	return null;
    }
    
    
    /*
     * Find the specified user in the database by email
     * 
     * @param database the name of the database
     * @param securityAns the security answer input
     */
    @Override
    public boolean findAnswer(String database, String securityAns) {
    	
    	// PreparedStatement where it pulls a piece of data that matches
    	String sql = "SELECT email, securityAns FROM Users WHERE email = ? and securityAns = ?";
    	
    	// Establishes a connection to the database and creates a statement
    	try (Connection con = this.connect(database);
                PreparedStatement statement  = con.prepareStatement(sql)) {
    		
    		// Gets the "active" or "logged in" email
    		String email = this.getStoredEmail(database);
    		System.out.println(email);
    		statement.setString(1, email);
    		statement.setString(2, securityAns);
    		
    		// Check if that security answer is found in the database
    		// under the specified email
    		ResultSet rs  = statement.executeQuery();
    		if (rs.next()) {
                System.out.println(rs.getString("email") + "\t" +
                		rs.getString("securityAns"));
                
                // Checks to see if there is no other user
                // with the same data, though this should be
                // impossible
                if (rs.next() == false) {
                	con.close();
                	rs.close();
                	statement.close();
                	return true;
                }
            }
    		return false;
    		
    	} catch (SQLException e) {
    		e.printStackTrace();
    		
    	} 
    	return false;
    }
    

}
