package application.databaseConnector.userData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import application.databaseConnector.SQLiteConnectorInt;
import application.personalIndexCardManager.User;
import edu.sjsu.yazdankhah.crypto.util.PassUtil;

public class SQLiteUserUpdater implements SQLiteConnectorInt, UserDataUpdatable{

	 /*
     * Inserts a new user into the database
     * 
     * @param database the name of the database
     * @param user the user to be added to the database
     */
	@Override
    public void addUser(String database, User user) {
    	String sql = "INSERT INTO Users (email, password, securityQuest, securityAns) VALUES(?,?,?,?)";

    	// Establishes a connection to the database
    	// Prepares a statement
    	try (Connection conn = this.connect(database);
    			PreparedStatement statement = conn.prepareStatement(sql)) {
    		
    		//get pass and encrypt it
    		String pass = user.getPass();
    		String encryptedPass = new PassUtil().encrypt(pass);
    		
    		// Extracts data from user object and put into database
    		statement.setString(1, user.getEmail());
    		statement.setString(2, encryptedPass);
    		statement.setString(3, user.getSecurityQuest());
    		statement.setString(4, user.getSecurityAns());
           
    		// Updates database
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		conn.close();
    		statement.close();
    		System.out.println("Added new user");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
    /*
     * Stores the email input 
     * 
     * @param database the name of the database
     */
	@Override
	public void storeEmailInput(String database, String emailInput) {
    	
    	// Removes any stored or "active" email
    	this.removeStoredEmail(database);
    	
    	// PreparedStatement String to insert email input into database
    	String sql = "INSERT INTO GETEMAIL (EMAIL) VALUES(?)";

    	// Establishes a connection to the database
    	// Prepares a statement
    	try (Connection conn = this.connect(database);
    			PreparedStatement statement = conn.prepareStatement(sql)) {
    		
    		// Extracts data from user object and put into database
    		statement.setString(1, emailInput);
    		System.out.println("Stored " + emailInput);
           
    		// Updates database
    		statement.executeUpdate();
    		conn.close();
        	statement.close();
    		System.out.println("Updated stored email in the database table");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
    /*
     * Resets the password of the account in the specified table
     * in the specified database
     * 
     * @param database the name of the database
     * @param newPassword the new password
     */
    @Override
	public void updatePassword(String database, String newPassword) {
		
		// PreparedStatement String to update the password to its new password
		// corresponding to the stored email
		String sql = "UPDATE Users SET password = ? "
                + "WHERE email = ?";

        try (Connection conn = this.connect(database);
                PreparedStatement statement = conn.prepareStatement(sql)) {

        	// Encrypt new password
        	String encryptedPassword = new PassUtil().encrypt(newPassword);
        	
        	System.out.println("Resetting password...");
        	System.out.println("New Password: " + newPassword + " | " + encryptedPassword);
        	
            // set the password to the new password
        	String email = this.getStoredEmail(database);
            statement.setString(1, encryptedPassword);
            statement.setString(2, email);
           
            // Updates the password
            statement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
    
    /*
     * Updates the "logged in" or active email
     * to its new email
     * 
     * @param database the name of the database
     * @param newEmail the new email to replace the old
     */
	@Override
	public void updateEmail(String database, String newEmail) {
		// PreparedStatement String to update the "logged in" email to its new email
		String sql = "UPDATE Users SET email = ?"
				+ "WHERE email = ?";
		
		try {
			// Connects to database and prepares a statement to execute
			// what the sql String wants to do
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Fills in the parameters of the sql String
			pstm.setString(1, newEmail);
			pstm.setString(2, this.getStoredEmail(database)); // Gets the active email in order to replace it
			
			// Updates the database
			pstm.executeUpdate();
			
			// Closes connection and statement to
			// prevent background leakage
			con.close();
			pstm.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
	}

	/*
	 * Updates the security question and security answer
	 * 
	 * @param database the name of the database
	 * @param newSecurityQuestion the new security question that the user had selected
	 * @param newSecurityAnswer the new security answer that the user had selected
	 */
	@Override
	public void updateSecurity(String database, String newSecurityQuestion, String newSecurityAnswer) {
		// PreparedStatement String to update the security question and the security answer
		String sql = "UPDATE Users SET securityQuest = ?, securityAns = ?"
				+ "WHERE email = ?";
		
		try {
			// Connects to database and prepares a statement to execute
			// what the sql String wants to do
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Fills in the parameters of the sql String
			pstm.setString(1, newSecurityQuestion);
			pstm.setString(2, newSecurityAnswer);
			pstm.setString(3, this.getStoredEmail(database)); // Gets the active/logged in email in order
															  // to update database at specified location
			
			// Updates the database
			pstm.executeUpdate();
			
			// Closes connection and statement to
			// prevent background leakage
			con.close();
			pstm.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
    
	/*
     * Deletes the user based on the current "active"
     * email. Restricted to only deleting the "logged in"
     * account
     * 
     * @param database the name of the database
     */
	@Override
	public void deleteUser(String database) {
		// PreparedStatement String to delete the current account
		String sql = "DELETE FROM Users WHERE email = ?";
		
		try {
			// Establishes a connection to the database
			// & prepares a statement to execute sql String
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Sets the parameter for account deletion to the
			// "logged in" email
			pstm.setString(1, this.getStoredEmail(database));
			
			// Updates the database
			pstm.executeUpdate();
			
			// Closes connection and PreparedStatement to
			// prevent background leakage
			con.close();
			pstm.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
}
