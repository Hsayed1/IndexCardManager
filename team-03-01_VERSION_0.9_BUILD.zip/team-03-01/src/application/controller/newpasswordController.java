package application.controller;

import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.userData.SQLiteUserAccessor;
import application.databaseConnector.userData.SQLiteUserUpdater;
import application.databaseConnector.userData.UserDataUpdatable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class newpasswordController implements Initializable 
{
	private final static String DATABASE = "usersTest.db";
	
	@FXML private PasswordField newPassword;
	@FXML private Button submitBtn;
	@FXML private Label errorMess;
	
	
	@FXML
	public void resetPasswordOp(ActionEvent event) {
		if (newPassword.getText().isEmpty()) {
			errorMess.setText("***The new password cannot be left blank***");
			errorMess.setVisible(true);
		}
		else {
			errorMess.setVisible(false);
			String password = newPassword.getText();
			//get password from database and change it to new password
			UserDataUpdatable con = new SQLiteUserUpdater();
			SQLiteConnectorInt con2 = new SQLiteUserAccessor();
	
			con.updatePassword(DATABASE, password);
			con2.removeStoredEmail(DATABASE); 		// removes "active" email as it is no longer needed
		
			//return to home screen
			Stage stage = (Stage)submitBtn.getScene().getWindow();
			stage.close();
			Main m = new Main();
			m.changeScene("fxml/Home.fxml");
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		errorMess.setVisible(false);
		
	}

}
