package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.courseData.SQLiteCourseAccessor;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.layout.FlowPane;

public class IndexCardsController implements Initializable {
	
	private static final String DATABASE = "usersTest.db";

	@FXML private Button toCoursesBtn;
	@FXML private Button deleteBtn;
	@FXML private Button renameBtn;
	@FXML private Button createCardButton;
	@FXML private FlowPane indexCardsPanel;
	@FXML private Label currentCourse;
	@FXML private Button reviewCardsBtn;


	@FXML public void goToCourses(ActionEvent event) {
		
		// Removes "active" status of current course
		SQLiteConnectorInt con = new SQLiteCourseAccessor();
		con.removeCurrentCourse(DATABASE);
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/Courses.fxml");
								
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * Change logout button color when mouse hovers
	 * over the button
	 * 
	 */
	@FXML public void changeToCoursesBtnColor() {
		toCoursesBtn.setStyle("-fx-background-color: #06014a");
		toCoursesBtn.setTextFill(Color.WHITE);
	}
	
	/*
	 * Reverts logout button color when mouse exits
	 * the button
	 * 
	 */
	@FXML public void revertToCoursesBtnColor() {
		toCoursesBtn.setStyle("-fx-background-color: #F9FEB5");
		toCoursesBtn.setTextFill(Color.BLACK);
	}

	/*
	 * Rename the selected course
	 * 
	 */
	@FXML public void renameCourse() {
		// Creates course renaming prompt
		String fxml = "fxml/CourseRename.fxml";
		String title = "Rename the Course";
		double width = 500;
		double height = 300;
		this.createPrompt(fxml, title, width, height);
	}

	/*
	 * Deletes the selected course
	 * 
	 */
	@FXML public void deleteCourse(ActionEvent event) {
		// Create course deletion prompt
		String fxml = "fxml/CourseDeletion.fxml";
		String title = "Delete the Course";
		double width = 500;
		double height = 300;
		this.createPrompt(fxml, title, width, height);
	}
	
	/*
	 * Change button color when mouse enters
	 * the button
	 * 
	 */
	@FXML public void changeICCreationColor() {
		createCardButton.setStyle("-fx-background-color: #e5938a");
		createCardButton.setTextFill(Color.BLACK);
	}

	/*
	 * Reverts button color back to original
	 * color
	 * 
	 */
	@FXML public void revertICCreationColor() {
		createCardButton.setStyle("-fx-background-color: #1a6c75");
		createCardButton.setTextFill(Color.WHITE);
	}
	
	/*
	 * Create a new index card
	 */
	@FXML public void createIndexCard(ActionEvent event) {
		//Open new window where the user can enter the card info
		String fxml = "fxml/CreateIndexCard.fxml";
		String title = "Create Index Card";
		double width = 600;
		double height = 402;
		this.createPrompt(fxml, title, width, height);
	}

	@FXML public void reviewIndexCards(ActionEvent event) {
		URL url = getClass().getClassLoader().getResource("fxml/ReviewCards.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * Creates new prompt
	 * 
	 */
	private void createPrompt(String fxml, String title, double width, double height) {
		try {
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource(fxml));
			
			// Settings for the prompt
			primaryStage.setTitle(title);
			primaryStage.setScene(new Scene(root, width, height));
			primaryStage.alwaysOnTopProperty();
			primaryStage.centerOnScreen();
			primaryStage.setResizable(false);
			primaryStage.initModality(Modality.APPLICATION_MODAL);
			primaryStage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private Button newIndexCard(String term, String definition) {
		Button btn = new Button(term + " | " + definition);
		return btn;
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Display name of course
		SQLiteConnectorInt con = new SQLiteCourseAccessor();
		currentCourse.setText("Your Index Cards - " + con.getCurrentCourse(DATABASE));
		
		//Connects to database to get index cards
		IndexCardDataInt icCon = new SQLiteIndexCard();
		
		// Displays index cards associated with the current course
		// and current account
		for (IndexCard ic: icCon.getIndexCards(DATABASE)) {
			Button newIC = newIndexCard(ic.getTerm(), ic.getDefinition());
			
			// Allows each index card to be able to modify its contents
			newIC.setOnAction(new EventHandler<ActionEvent>() {				
				@Override
				public void handle(ActionEvent event) {
					// Allows each index card to display a modify index card prompt
					String fxml = "fxml/ModifyIndexCard.fxml";
					String title = "Modify Index Card";
					double width = 500;
					double height = 300;
					
					icCon.storeCurrentIndexCard(DATABASE, ic);
					createPrompt(fxml, title, width, height);	
				}		
			});
			
			// Button settings
			newIC.setFont(Font.font(18));
			newIC.setStyle("-fx-background-color: #9ecc16");
			newIC.setTextFill(Color.BLACK);
			newIC.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> newIC.setStyle("-fx-background-color: #6133E9"));
			newIC.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> newIC.setTextFill(Color.WHITE));
			newIC.addEventHandler(MouseEvent.MOUSE_EXITED, e -> newIC.setStyle("-fx-background-color: #9ecc16"));
			newIC.addEventHandler(MouseEvent.MOUSE_EXITED, e -> newIC.setTextFill(Color.BLACK));
			
			// Adds new index card to panel
			indexCardsPanel.getChildren().add(newIC);
		}
		
		// Button settings (mostly for color change) for Delete Course button
		deleteBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> deleteBtn.setStyle("-fx-background-color: #e5938a"));
		deleteBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> deleteBtn.setTextFill(Color.BLACK));
		deleteBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> deleteBtn.setStyle("-fx-background-color: #1a6c75"));
		deleteBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> deleteBtn.setTextFill(Color.WHITE));
		
		// Button settings (mostly for color change) for Rename Course button
		renameBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> renameBtn.setStyle("-fx-background-color: #e5938a"));
		renameBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> renameBtn.setTextFill(Color.BLACK));
		renameBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> renameBtn.setStyle("-fx-background-color: #1a6c75"));
		renameBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> renameBtn.setTextFill(Color.WHITE));
		
		// Button settings (mostly for color change) for Review Index Cards button
		reviewCardsBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> reviewCardsBtn.setStyle("-fx-background-color: #e5938a"));
		reviewCardsBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> reviewCardsBtn.setTextFill(Color.BLACK));
		reviewCardsBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> reviewCardsBtn.setStyle("-fx-background-color: #1a6c75"));
		reviewCardsBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> reviewCardsBtn.setTextFill(Color.WHITE));
	}

}
