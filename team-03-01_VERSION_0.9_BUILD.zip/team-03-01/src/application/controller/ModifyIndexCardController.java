package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.CheckBox;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class ModifyIndexCardController implements Initializable {

	private final static String DATABASE = "usersTest.db";
	
	@FXML private TextField termInput;
	@FXML private TextField defInput;
	@FXML private CheckBox isLearnedCB;
	@FXML private Button deleteICBtn;
	@FXML private Button backBtn;
	@FXML private Button commitModICBtn;
	@FXML private Label errorLbl;
	@FXML private Label statusLbl;
	
	/*
	 * Changes text of check box depending
	 * on whether it is checked or not
	 * 
	 */
	@FXML public void updateIsLearned() {
		// Connects to database
		IndexCardDataInt con = new SQLiteIndexCard();
		
		if (isLearnedCB.isSelected()) {
			isLearnedCB.setText("Learned");
			statusLbl.setText("Learned - Updated Index Card");
			statusLbl.setTextFill(Color.LIGHTGREEN);
			con.updateIsLearned(DATABASE, isLearnedCB.isSelected());
			return;
		}
		isLearnedCB.setText("Not Learned");
		statusLbl.setText("Not Learned - Updated Index Card");
		statusLbl.setTextFill(Color.PALEVIOLETRED);
		con.updateIsLearned(DATABASE, isLearnedCB.isSelected());
	}
	
	/*
	 * Goes to index card deletion window
	 * 
	 */
	@FXML public void deleteIC(ActionEvent event) {
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource("fxml/DeleteIndexCard.fxml");
								
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
									
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * Goes back to Index Card Panel
	 * 
	 */
	@FXML public void backToICPanel(ActionEvent event) {
		
		// removes "active" status of current index card
		SQLiteConnectorInt con = new SQLiteIndexCard();
		con.removeCurrentIndexCard(DATABASE);
		
		// Closes prompt and returns to index card panel
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.close();
		Main m = new Main();
		m.changeScene("fxml/IndexCard.fxml");
	}
	
	@FXML public void commitModIC(ActionEvent event) {
		// Connects to database 
		IndexCardDataInt con = new SQLiteIndexCard();
		SQLiteConnectorInt con2 = new SQLiteIndexCard();
		
		IndexCard ic = new IndexCard(termInput.getText(), defInput.getText(), con2.getCurrentCourse(DATABASE), isLearnedCB.isSelected());
		
		// Checks to see if there is an identical index card
		if (con.checkIdenticalIC(DATABASE, ic)) {
			errorLbl.setText("***That index card already exists***");
			errorLbl.setVisible(true);
			return;
		}
		errorLbl.setVisible(false);
		// updates index card
		con.updateIndexCard(DATABASE, ic);
		
		// Closes prompt and updates Index Card Panel
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.close();
		Main m = new Main();
		m.changeScene("fxml/IndexCard.fxml");
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		errorLbl.setVisible(false);
		
		// Gets contents of current index card
		SQLiteConnectorInt con = new SQLiteIndexCard();
		
		// Loads current details of index card
		termInput.setText(con.getCurrentIndexCard(DATABASE).getTerm());
		defInput.setText(con.getCurrentIndexCard(DATABASE).getDefinition());
		isLearnedCB.setSelected(con.getCurrentIndexCard(DATABASE).getIsLearned());
		
		// Presets the check box
		if (con.getCurrentIndexCard(DATABASE).getIsLearned()) {
			isLearnedCB.setText("Learned");
			statusLbl.setText("Learned");
			statusLbl.setTextFill(Color.LIGHTGREEN);
		}
		else {
			isLearnedCB.setText("Not Learned");
			statusLbl.setText("Not Learned");
			statusLbl.setTextFill(Color.PALEVIOLETRED);
		}
		
		// Button settings (mostly for color change) for delete button
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> deleteICBtn.setStyle("-fx-background-color: #0f0fc0;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> deleteICBtn.setTextFill(Color.WHITE));
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> deleteICBtn.setStyle("-fx-background-color: #F0F03F;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		deleteICBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> deleteICBtn.setTextFill(Color.BLACK));
		
		// Button settings (mostly for color change) for modification button
		commitModICBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> commitModICBtn.setStyle("-fx-background-color: #0f0fc0;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		commitModICBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> commitModICBtn.setTextFill(Color.WHITE));
		commitModICBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> commitModICBtn.setStyle("-fx-background-color: #F0F03F;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		commitModICBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> commitModICBtn.setTextFill(Color.BLACK));
		
		// Button settings (mostly for color change) for back button
		backBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> backBtn.setStyle("-fx-background-color: #0f0fc0;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		backBtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> backBtn.setTextFill(Color.WHITE));
		backBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> backBtn.setStyle("-fx-background-color: #F0F03F;"
																					+ "-fx-border-radius: 15px;"
																					+ "-fx-border-color: BLACK;"
																					+ "-fx-background-radius: 15px"));
		backBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> backBtn.setTextFill(Color.BLACK));
	}

}
