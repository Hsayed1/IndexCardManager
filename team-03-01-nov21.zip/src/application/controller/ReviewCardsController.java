package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class ReviewCardsController implements Initializable{

	private static final String DATABASE = "usersTest.db";
	private static String selection;
	private int numOfLearnedCards;
	private int numOfNotLearnedCards;
	
	@FXML private Label errorLbl;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// Hide label
		errorLbl.setVisible(false);
		
		// Gets index cards to check if there are enough of
		// certain kinds of index cards in the list
		IndexCardDataInt con = new SQLiteIndexCard();
		numOfLearnedCards = 0;
		numOfNotLearnedCards = 0;
		
		// Checks number of learned/unlearned cards
		for (IndexCard ic : con.getIndexCards(DATABASE)) {
			System.out.println(ic.toString());
			if (ic.getIsLearned())
				numOfLearnedCards++;
			else
				numOfNotLearnedCards++;
		}
		
	}

	@FXML public void reviewAllOp(ActionEvent event) {
		// checks to see if list is empty as cards are split into 
		// two categories
		if (numOfLearnedCards == 0 && numOfNotLearnedCards == 0) {
			errorLbl.setText("***There are no index cards to review***");
			errorLbl.setVisible(true);
			return;
		}
		errorLbl.setVisible(false);
		selection = "Review all";
		this.changeScene(event, "fxml/Reviewer.fxml");
	}

	@FXML public void reviewLearnedOp(ActionEvent event) {
		// checks to see if number of learned cards are more than 0
		if (numOfLearnedCards == 0) {
			errorLbl.setText("***There are no learned index cards to review***");
			errorLbl.setVisible(true);
			return;
		}
		errorLbl.setVisible(false);
		selection = "Review learned";
		this.changeScene(event, "fxml/Reviewer.fxml");
	}

	@FXML public void reviewUnlearnedOp(ActionEvent event) {
		// checks to see if number of not learned cards are more than 0
		if (numOfNotLearnedCards == 0) {
			errorLbl.setText("***There are no not learned index cards to review***");
			errorLbl.setVisible(true);
			return;
		}
		errorLbl.setVisible(false);
		selection = "Review unlearned";
		this.changeScene(event, "fxml/Reviewer.fxml");
	}
	
	/*
	 * Changes the scene from one scene to another
	 * 
	 */
	private void changeScene(ActionEvent event, String fxml) {
		
		// Changes the scene from one window to another window
		URL url = getClass().getClassLoader().getResource(fxml);
						
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
							
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	static String getSelection() {
		return selection;
	}

	@FXML public void backOp(ActionEvent event) {
		URL url = getClass().getClassLoader().getResource("fxml/IndexCard.fxml");
		
		try {
			// Loads the other scene
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
								
		} catch (IOException e){
			e.printStackTrace();
		}
	}

}
