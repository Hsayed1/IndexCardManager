package application.controller;

import javafx.fxml.FXML;

import application.Main;
import application.databaseConnector.SQLiteConnectorInt;
import application.databaseConnector.courseData.SQLiteCourseAccessor;
import application.databaseConnector.indexCardData.IndexCardDataInt;
import application.databaseConnector.indexCardData.SQLiteIndexCard;
import application.personalIndexCardManager.IndexCard;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class CreateIndexCardController {
	
	private final static String DATABASE = "usersTest.db";
	
	@FXML TextField termTextField;
	@FXML TextField definitionTextField;
	@FXML Button doneButton;
	
	
	@FXML public void Done(ActionEvent event) {
		String term = termTextField.getText();
		String definition = definitionTextField.getText();
		
		
		// Stage 1: Initialize connection with the database 
		IndexCardDataInt con = new SQLiteIndexCard();
		SQLiteConnectorInt con2 = new SQLiteCourseAccessor();
		
		// Stage 2: Add course to the database
		//(Finished) 	1) I need to create an index card class inside the personalIndexCardManager
		//(In Progress) 2) Create an addIndexCard function inside SQLConnector.java
		
		con.addIndexCard(DATABASE, new IndexCard(term, definition, con2.getCurrentCourse(DATABASE)));
		Stage stage = (Stage)doneButton.getScene().getWindow();
		stage.close();
		Main m = new Main();
		m.changeScene("fxml/IndexCard.fxml");
	}
	

}
