package application.databaseConnector.courseData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import application.databaseConnector.SQLiteConnectorInt;
import application.personalIndexCardManager.Course;

/*
 * This class handles ALL data updates concerning Courses
 * 
 */
public class SQLiteCourseUpdater implements SQLiteConnectorInt, CourseDataUpdatable {

    /*
     * Stores the current course
     * 
     * @param database the name of the database
     * @param currentCourse the current course being accessed
     */
	@Override
    public void storeCurrentCourse(String database, Course currentCourse) {
    	
    	// Removes any stored/"active" course
    	this.removeCurrentCourse(database);
    	
    	// PreparedStatement String to insert course name input into database
    	String sql = "INSERT INTO GetCourseName (CourseName) VALUES(?)";

    	// Establishes a connection to the database
    	// Prepares a statement to execute the sql String
    	try (Connection conn = this.connect(database);
    			PreparedStatement statement = conn.prepareStatement(sql)) {
    		
    		// Extracts data from course object and put into database
    		statement.setString(1, currentCourse.getName());
    		System.out.println("Stored " + currentCourse.getName());
           
    		// Updates database
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		conn.close();
        	statement.close();
    		System.out.println("Updated stored course in the database table");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /*
     * Add a course to the user's courses
     * 
     * @param database the name of the database
     * @param course the new course to be added
     */
	@Override
    public void addCourse(String database, Course course) {
    	// PreparedStatement String to add a new course to the database
    	String sql = "INSERT INTO Courses (email, courseName) VALUES(?,?)";
    	try {
    		// Connects to database & prepares a statement to execute
    		// the sql Sring
    		Connection con = this.connect(database);
    		PreparedStatement statement = con.prepareStatement(sql);
    		
    		// Stores the relevant data into the Courses table of database
    		statement.setString(1, this.getStoredEmail(database));
    		statement.setString(2, course.getName());
    		
    		// Update Courses table in database
    		statement.executeUpdate();
    		
    		// Closes connection and prepared statement 
    		// from running in the background
    		con.close();
    		statement.close();
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    
    /*
     * Updates the course name when being renamed
     * 
     * @param database the name of the database
     * @param newCourse the new course
     */
	@Override
    public void updateCourseName(String database, Course newCourse) {
    	
    	// PreparedStatement String to update the name of the course
    	String sql = "UPDATE Courses SET courseName = ? WHERE email = ? and courseName = ?";
    	
    	try {
    		// Establishes a connection to the database
    		// Prepares to execute action provided by sql String
    		Connection con = this.connect(database);
    		PreparedStatement pstmt = con.prepareStatement(sql);
    		System.out.println(newCourse.getName());
    		
    		// Located course in database with the desired parameters
    		pstmt.setString(1, newCourse.getName());
    		pstmt.setString(2, this.getStoredEmail(database));
    		pstmt.setString(3, this.getCurrentCourse(database));
    		
    		// Updates the database
    		pstmt.executeUpdate();
    		
    		// Closes the connection and prepared statement
    		con.close();
    		pstmt.close();
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    /*
     * Deletes specified course
     * 
     * @param database the name of the database
     */
	@Override
    public void deleteCourse(String database) {
    	// PreparedStatement string to remove specified course from database table
    	String sql = "DELETE FROM Courses where email = ? and courseName = ?";
    	try {
    		// Connects to database and prepares a statement to remove data
    		Connection con = this.connect(database);
    		PreparedStatement statement = con.prepareStatement(sql);
    		
    		// Sets the parameters for the statement to execute its
    		// function in deleting the selected course under 
    		// the current "logged in" email
    		statement.setString(1, this.getStoredEmail(database));
    		Course course = new Course(this.getCurrentCourse(database));
    		statement.setString(2, course.getName());
    		
    		// updates table to remove the current course that
    		// the user is currently accessing
    		statement.executeUpdate();
    		
    		// Closes connection and statement
    		con.close();
    		statement.close();
    	} catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    

	/*
	 * Deletes ALL Courses associated with the "logged in"
	 * account. This is RESTRICTED to only deleting courses
	 * associated with the "logged in" account.
	 * 
	 * @param database the name of the database
	 */
	@Override
	public void deleteAllCourses(String database) {
		// PreparedStatement String to delete ALL courses associated with the account
		String sql = "DELETE FROM Courses WHERE email = ?";
		
		try {
			// Connects to the database & prepares a statement to
			// execute the sql String
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Sets the parameters of the sql String to the
			// "active email" in order to delete all courses
			// associated with this "active" email
			pstm.setString(1, this.getStoredEmail(database));
			
			// Updates the database of the latest changes
			pstm.executeUpdate();
			
			// Closes connection and statement
			// to prevent background leakage
			con.close();
			pstm.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Updates all courses associated with the "active" account.
	 * 
	 * @precondition the current stored email must not updated to the new email
	 * @param database the name of the database
	 * @param newEmail the new email address to associate the courses with
	 */
	@Override
	public void updateAssociatedEmail(String database, String newEmail) {
		// PreparedStatement String to update all courses associated with the old
		// email to the new email
		String sql = "UPDATE Courses SET email = ?"
				+ "WHERE email = ?";
		
		try {
			// Connects to database and prepares a statement
			// to execute what the sql String wants to do
			Connection con = this.connect(database);
			PreparedStatement pstm = con.prepareStatement(sql);
			
			// Sets the parameters of the sql String in order
			// to change the old email to the new email as 
			// part of modification 
			pstm.setString(1, newEmail);
			pstm.setString(2, this.getStoredEmail(database));
			
			// Updates the database
			pstm.executeUpdate();
			
			// Closes connection and statement to
			// prevent background leakages
			con.close();
			pstm.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
